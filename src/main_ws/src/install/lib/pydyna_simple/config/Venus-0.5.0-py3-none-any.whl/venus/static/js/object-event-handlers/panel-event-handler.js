"use strict";

function updateDataPanelObject(updateInfo, oldObj, tooltip) {
    if (updateInfo.ctx[2].i != null) {
        var i = updateInfo.ctx[2].i;

        var element;
        if (tooltip) {
            element = oldObj.visual.getTooltip().getContent().children[i];
        } else {
            element = oldObj.visual.children[i];
        }
        if (oldObj.obj.data_panel[i].__class__ == "KeyValue") {
            if (updateInfo.ctx[3].prop == "key") {
                element.children[0].innerText = updateInfo.value;
                oldObj.obj.data_panel[i]["key"] = updateInfo.value;
            }
            else if (updateInfo.ctx[3].prop == "value") {
                element.children[1].innerText = updateInfo.value;
                oldObj.obj.data_panel[i]["value"] = updateInfo.value;
            }
            else {
                console.error("invalid property to update on panel", updateInfo);
            }
        } else if (oldObj.obj.data_panel[i].__class__ == "Button") {
            if (updateInfo.ctx[3].prop == "uid") {
                element.children[0].dataset.uid = updateInfo.value;
                oldObj.obj.data_panel[i]["uid"] = updateInfo.value;
            }
            else if (updateInfo.ctx[3].prop == "name") {
                element.children[0].innerText = updateInfo.value;
                oldObj.obj.data_panel[i]["name"] = updateInfo.value;
            }
            else {
                console.error("invalid property to update on panel", updateInfo);
            }
        } else if (oldObj.obj.data_panel[i].__class__ == "Checkbox") {
            if (updateInfo.ctx[3].prop == "uid") {
                element.children[0].dataset.uid = updateInfo.value;
                oldObj.obj.data_panel[i]["uid"] = updateInfo.value;
            }
            else if (updateInfo.ctx[3].prop == "label") {
                element.childNodes[1].nodeValue = updateInfo.value;
                oldObj.obj.data_panel[i]["label"] = updateInfo.value;
            }
            else if (updateInfo.ctx[3].prop == "checked") {
                element.children[0].checked = updateInfo.value;
                oldObj.obj.data_panel[i]["checked"] = updateInfo.value;
            }
            else {
                console.error("invalid property to update on panel", updateInfo);
            }
        } else if (oldObj.obj.data_panel[i].__class__ == "Textbox") {
            if (updateInfo.ctx[3].prop == "value") {
                element.value = updateInfo.value;
                oldObj.obj.data_panel[i]["value"] = updateInfo.value;
            }
            else if (updateInfo.ctx[3].prop == "disabled") {
                if (updateInfo.value == true) {
                    element.setAttribute("disabled", "");
                } else {
                    element.removeAttribute("disabled");
                }
            }
            else {
                console.error("invalid property to update on panel", updateInfo);
            }
        } else {
            console.error("invalid property to update on panel", updateInfo);
        }
    }
    else {
        console.error("invalid property to update on panel", updateInfo);
    }
}


class PanelEventHandler extends VenusObjectEventHandler {
    constructor(parentElement, socket) {
        super();
        this.parentElement = parentElement;
        this.socket = socket;
    }

    add(panel, _map, objects) {
        var propElements = propListToHtml(panel, panel.data_panel, this.socket);

        propElements.className = "data-panel";
        this.parentElement.appendChild(propElements);
        objects.push(new VenusObject(panel, propElements));
    }

    update(oldObj, updateInfo, map, objects) {
        if (updateInfo.ctx.length == 2) {
            if (updateInfo.ctx[1].prop == "data_panel") {
                var tooltipContent = propListToHtml(oldObj.obj, updateInfo.value, this._socket);
                oldObj.visual.innerHTML = tooltipContent.innerHTML;
                oldObj.obj.data_panel = updateInfo.value;
            }
            else {
                console.error("invalid property to update on panel", updateInfo);
            }
        }
        else if (updateInfo.ctx.length == 3) {
            if (updateInfo.ctx[1].prop == "data_panel") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;
                    var newPropHtml = propToHtml(oldObj.obj, updateInfo.value, this._socket);
                    if (i < oldObj.visual.children.length) {
                        oldObj.visual.children[i].outerHTML = newPropHtml.outerHTML;
                    }
                    else {
                        oldObj.visual.appendChild(newPropHtml);
                    }
                    oldObj.obj.data_panel[i] = updateInfo.value;
                }
                else {
                    console.error("invalid property to update on panel", updateInfo);
                }
            }
            else {
                console.error("invalid property to update on panel", updateInfo);
            }
        }
        else if (updateInfo.ctx.length == 4) {
            if (updateInfo.ctx[1].prop == "data_panel") {
                updateDataPanelObject(updateInfo, oldObj, false);
            }
            else {
                console.error("invalid property to update on panel", updateInfo);
            }
        }
    }

    delete_(oldObj, updateInfo, map, objects) {
        if (updateInfo.ctx.length == 3) {
            if (updateInfo.ctx[1].prop == "data_panel") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;
                    oldObj.visual.children[i].remove();
                    oldObj.obj.data_panel.splice(i, 1);
                } else {
                    console.error("invalid property to delete on panel", updateInfo);
                }
            }
            else {
                console.error("invalid property to delete on line", updateInfo);
            }
        }
        else {
            console.error("invalid property to delete on line", updateInfo);
        }
    }

    remove(panel, map, objects) {
        panel.visual.remove();
    }
}