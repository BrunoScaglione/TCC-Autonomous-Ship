"""
O módulo `evented` contém classes que permitem a criação de objetos que geram eventos
sempre que alguma de suas propriedades é alterada. Dessa forma é possível que o usuário
da API use objetos exatamente como usaria qualquer objeto Python e o resto do código consiga
acompanhar possíveis alterações.
"""

from typing import Union, List, Dict, Tuple, Any, Callable
from collections.abc import MutableSequence, MutableMapping


class Uid:
    def __init__(self, uid):
        self.uid = uid

    def __repr__(self):
        return f"(uid:{self.uid})"

    def as_dict(self):
        return {"uid": self.uid}


class Property:
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return f"(prop:{self.name})"

    def as_dict(self):
        return {"prop": self.name}


class ArrayElement:
    def __init__(self, index):
        self.index = index

    def __repr__(self):
        return f"(i:{self.index})"

    def as_dict(self):
        return {"i": self.index}


"""
`Context` é utilizado para identificar alterações nos objetos `Evented`. 
Exemplo: ao alterar o ângulo do `Rudder` de um `Vessel` com id 0, o contexto pode ser:
    `[Uid(0), Property("rudders"), ArrayElement(0), Property("angle")]`
"""
Context = Union[Uid, Property, ArrayElement]

"""
`Primitives` são tipos que são retornados diretamente para o usuário sem
se tornarem instâncias de `Evented`.  
"""
Primitives = (int, float, str, bool, Callable)  # type: Tuple

"""
`OnChange` e `OnDelete` são os callbacks que objetos `Evented` chamam.
"""
OnChange = Callable[[List[Context], Any], None]
OnDelete = Callable[[List[Context]], None]


class Evented:
    """
    Um objeto `Evented` funciona como um wrapper para qualquer tipo de objeto. Ele tenta
    ser transparente de forma que você pode usar uma instância de `Evented` da mesma
    forma que usaria o objeto no interior dele. A classe também garante que ao acessar
    propriedades do objeto interno o usuário recebe uma nova instância de `Evented`.
    O objetivo da classe `Evented` é identificar alterações no objeto interno e gerar
    eventos que descrevam a alteração e o "caminho" necessário para repeti-las.
    """
    def __init__(
        self, inner, ctx: List[Context], on_change: OnChange, on_delete: OnDelete
    ):
        object.__setattr__(self, "_inner", inner)
        object.__setattr__(self, "_ctx", ctx)
        object.__setattr__(self, "_server", None)
        object.__setattr__(self, "_on_change_callback", on_change)
        object.__setattr__(self, "_on_delete_callback", on_delete)

    def process_value(self, value, extra_ctx: List[Context]):
        """
        Ao acessar qualquer propriedade do objeto interno do `Evented`, dependendo do tipo
        um valor diferente é retornado. Dessa forma o usuário pode acessar ou guardar
        propriedades filhas do objeto interno e ao fazer uma alteração ainda é possível
        gerar os eventos com o contexto correto.
        """
        if isinstance(value, Primitives):
            return value
        elif isinstance(value, list):
            return EventedList(
                value, self.ctx() + extra_ctx, self._on_change(), self._on_delete()
            )
        elif isinstance(value, dict):
            return EventedDict(
                value, self.ctx() + extra_ctx, self._on_change(), self._on_delete()
            )
        else:
            return EventedObject(
                value, self.ctx() + extra_ctx, self._on_change(), self._on_delete()
            )

    def inner(self):
        return object.__getattribute__(self, "_inner")

    def ctx(self):
        return object.__getattribute__(self, "_ctx")

    def _call_on_change(self, ctx: List[Context], value):
        self._on_change()(ctx, value)

    def _on_change(self) -> OnChange:
        return object.__getattribute__(self, "_on_change_callback")

    def _call_on_delete(self, ctx: List[Context]):
        self._on_delete()(ctx)

    def _on_delete(self) -> OnDelete:
        return object.__getattribute__(self, "_on_delete_callback")

    def __eq__(self, other):
        if isinstance(other, Evented):
            return self.inner().__eq__(other.inner())
        elif isinstance(other, self.inner().__class__):
            return self.inner().__eq__(other)
        else:
            return False

    def __hash__(self):
        return hash(self.inner())


class EventedObject(Evented):
    def __init__(
        self, inner, ctx: List[Context], on_change: OnChange, on_delete: OnDelete
    ):
        while isinstance(inner, EventedObject):
            inner = object.__getattribute__(inner, "_inner")
        super().__init__(inner, ctx, on_change, on_delete)

    def __getattr__(self, item):
        attr = object.__getattribute__(self.inner(), item)
        return self.process_value(attr, [Property(item)])

    def __setattr__(self, key, value):
        while isinstance(value, Evented):
            value = value.inner()

        old_value = object.__getattribute__(self.inner(), key)
        if old_value != value:
            self.inner().__setattr__(key, value)
            self._call_on_change(self.ctx() + [Property(key)], value)

    def __delattr__(self, item):
        # self.inner().__delattr__(item)
        # self._call_on_delete(self.ctx() + [Property(item)])
        raise RuntimeError("Deleting properties from objects is not allowed")


class EventedList(Evented, MutableSequence):
    def __init__(
        self, inner: List, ctx: List[Context], on_change: OnChange, on_delete: OnDelete
    ):
        super().__init__(inner, ctx, on_change, on_delete)

    def __len__(self):
        return len(self.inner())

    def __getitem__(self, index):
        if isinstance(index, slice):
            raise RuntimeError("slice indexing not supported.")

        item = self.inner()[index]
        if index >= 0:
            return self.process_value(item, [ArrayElement(index)])
        else:
            return self.process_value(item, [ArrayElement(len(self) + index)])

    def __delitem__(self, index):
        if isinstance(index, slice):
            raise RuntimeError("slice indexing not supported.")

        old_len = len(self)

        del self.inner()[index]
        if index >= 0:
            self._call_on_delete(self.ctx() + [ArrayElement(index)])
        else:
            self._call_on_delete(self.ctx() + [ArrayElement(old_len + index)])

    def insert(self, index, value):
        if isinstance(index, slice):
            raise RuntimeError("slice indexing not supported.")

        if not isinstance(index, int):
            raise RuntimeError("index is not an int")

        if index != len(self.inner()):
            raise RuntimeError("you can only insert at the end of the array")

        while isinstance(value, Evented):
            value = value.inner()

        old_len = len(self)

        self.inner().insert(index, value)
        if index >= 0:
            self._call_on_change(self.ctx() + [ArrayElement(index)], value)
        else:
            self._call_on_change(self.ctx() + [ArrayElement(old_len + index)], value)

    def __setitem__(self, index, value):
        if isinstance(index, slice):
            raise RuntimeError("slice indexing not supported.")

        while isinstance(value, Evented):
            value = value.inner()

        old_value = self.inner()[index]
        if old_value != value:
            self.inner()[index] = value
            if index >= 0:
                self._call_on_change(self.ctx() + [ArrayElement(index)], value)
            else:
                self._call_on_change(
                    self.ctx() + [ArrayElement(len(self) + index)], value
                )


class EventedDict(Evented, MutableMapping):
    def __init__(
        self, inner: Dict, ctx: List[Context], on_change: OnChange, on_delete: OnDelete
    ):
        super().__init__(inner, ctx, on_change, on_delete)

    def __setitem__(self, key, value):
        while isinstance(value, Evented):
            value = value.inner()

        try:
            old_value = self.inner()[key]
            if old_value != value:
                self.inner()[key] = value
        except KeyError:
            self.inner()[key] = value

        self._call_on_change(self.ctx() + [Property(key)], value)

    def __getitem__(self, key):
        item = self.inner()[key]
        return self.process_value(item, [Property(key)])

    def __delitem__(self, key):
        del self.inner()[key]
        self._call_on_delete(self.ctx() + [Property(key)])

    def __iter__(self):
        return iter(self.inner())

    def __len__(self):
        return len(self.inner())
