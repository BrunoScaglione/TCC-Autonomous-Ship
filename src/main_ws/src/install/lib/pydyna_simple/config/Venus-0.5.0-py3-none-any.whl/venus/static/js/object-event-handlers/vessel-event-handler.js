"use strict";

function createVesselPoly(position, angle, size) {
    var vesselCoords = [
        [142.5,0],
        [140.85,5.8877],
        [125.53,17.527],
        [106.94,22.828],
        [87.724,24.663],
        [68.402,24.695],
        [49.08,24.695],
        [29.758,24.695],
        [10.436,24.695],
        [-8.886,24.695],
        [-28.208,24.695],
        [-47.53,24.695],
        [-66.852,24.695],
        [-86.171,24.579],
        [-105.41,22.831],
        [-124.46,19.488],
        [-142.55,12.749],
        [-142.45,-12.856],
        [-124.08,-18.944],
        [-105.08,-22.514],
        [-85.87,-24.664],
        [-66.553,-24.802],
        [-47.231,-24.802],
        [-27.909,-24.802],
        [-8.5869,-24.802],
        [10.735,-24.802],
        [30.057,-24.802],
        [49.379,-24.802],
        [68.701,-24.802],
        [88.022,-24.73],
        [107.24,-22.835],
        [125.8,-17.437],
        [141,-5.6447],
        [142.5,0],
        [142.5,0],
    ];
    var normalizedCoords = vesselCoords.map(v => [ v[1]/24.802, v[0]/142.5 ]);
    var scaledCoords = normalizedCoords.map(v => [ v[0] * size.width/2, v[1] * size.height/2 ])
    var rotatedCoords = scaledCoords.map(v => {
        var angleRad = toRadians(angle);

        var x = v[0] * Math.cos(angleRad) + v[1] * Math.sin(angleRad);
        var y = v[1] * Math.cos(angleRad) - v[0] * Math.sin(angleRad);

        return [x, y];
    });
    var geoCoords = rotatedCoords.map(v => latLngFromDistance(position.latitude, position.longitude, v[0], v[1]));

    return geoCoords;
}

function createRudderPoly(vesselPosition, vesselAngle, vesselSize, rudderAngle, rudderLength) {
    var rudderAngle = toRadians(rudderAngle);
    var rudderLine = [0, vesselSize.height * -rudderLength];
    var rotatedRudderLine = [
        rudderLine[0] * Math.cos(rudderAngle) + rudderLine[1] * Math.sin(rudderAngle),
        rudderLine[1] * Math.cos(rudderAngle) - rudderLine[0] * Math.sin(rudderAngle),
    ];

    var lineStart = [0, -vesselSize.height/2];
    var lineEnd = [rotatedRudderLine [0], rotatedRudderLine[1] - vesselSize.height/2];

    var vesselAngle = toRadians(vesselAngle);
    var rotatedLineStart = [
        lineStart[0] * Math.cos(vesselAngle) + lineStart[1] * Math.sin(vesselAngle),
        lineStart[1] * Math.cos(vesselAngle) - lineStart[0] * Math.sin(vesselAngle),
    ];

    var rotatedLineEnd = [
        lineEnd[0] * Math.cos(vesselAngle) + lineEnd[1] * Math.sin(vesselAngle),
        lineEnd[1] * Math.cos(vesselAngle) - lineEnd[0] * Math.sin(vesselAngle),
    ];

    var start = latLngFromDistance(vesselPosition.latitude, vesselPosition.longitude, rotatedLineStart[0], rotatedLineStart[1]);
    var end = latLngFromDistance(vesselPosition.latitude, vesselPosition.longitude, rotatedLineEnd[0], rotatedLineEnd[1]);

    return [start, end];
}

class VesselVisual {
    constructor(vesselPoly, rudderPolygons, vesselRotationControlMarker, vesselRotationControlLine) {
        this.vesselPoly = vesselPoly;
        this.rudderPolygons = rudderPolygons;
        this.vesselRotationControlMarker = vesselRotationControlMarker;
        this.vesselRotationControlLine = vesselRotationControlLine;
    }

    getTooltip() {
        return this.vesselPoly.getTooltip();
    }
}

class VesselEventHandler extends VenusObjectEventHandler {
    constructor(socket, mousePosition) {
        super();
        this._socket = socket;
        this._mousePosition = mousePosition;

        this._default_vessel_visual_options = {};
        L.extend(this._default_vessel_visual_options, L.Layer.prototype.options);
        L.extend(this._default_vessel_visual_options, L.Path.prototype.options);
        L.extend(this._default_vessel_visual_options, L.Polyline.prototype.options);
        L.extend(this._default_vessel_visual_options, L.Polygon.prototype.options);

        this._default_rudder_visual_options = {};
        L.extend(this._default_rudder_visual_options, L.Layer.prototype.options);
        L.extend(this._default_rudder_visual_options, L.Path.prototype.options);
        L.extend(this._default_rudder_visual_options, L.Polyline.prototype.options);
    }

    add(vessel, map, objects) {
        var coords = createVesselPoly(vessel.position, vessel.angle, vessel.size);

        var poly = L.polygon(coords, { smoothFactor: 0, draggable: vessel.draggable }).addTo(map);
        poly._venus_uid = vessel.uid;

        poly.setStyle(vessel.visual_options);

        var controlLineCoords = [
            [vessel.position.latitude, vessel.position.longitude],
            latLngFromAngleLength(vessel.position.latitude, vessel.position.longitude, vessel.angle, Math.max(vessel.size.width, vessel.size.height) * 0.75),
        ];
        var controlLine = L.polyline(controlLineCoords, { smoothFactor: 0 }).addTo(map);
        controlLine.setStyle({"color": "gray", "dashArray": "5"});
        var controlIcon = L.divIcon({"className": "rotation-control-icon", iconSize: [20, 20],});
        var controlMarker = L.marker(
            controlLineCoords[1],
            {icon: controlIcon, draggable: true}
        ).addTo(map);
        controlMarker._venus_uid = vessel.uid;

        if (!vessel.can_rotate) {
            controlLine.removeFrom(map);
            controlMarker.removeFrom(map);
        }

        controlMarker.on('drag', (evt) => {
            var angle = angleFromCoordinate(
                vessel.position.latitude, vessel.position.longitude,
                evt.latlng.lat, evt.latlng.lng
            );

            var controlLineCoords = [
                [vessel.position.latitude, vessel.position.longitude],
                latLngFromAngleLength(vessel.position.latitude, vessel.position.longitude, angle, Math.max(vessel.size.width, vessel.size.height) * 0.75),
            ];
            controlLine.setLatLngs(controlLineCoords);
            controlMarker.setLatLng(controlLineCoords[1]);
        });

        controlMarker.on('dragstart', (evt) => {
            var obj = objects.find((o) => o.obj.uid == evt.target._venus_uid);
            this._socket.send(JSON.stringify(
                {
                    "__class__": "ObjectRotateStart",
                    "object_uid": obj.obj.uid,
                }
            ));
        });

        controlMarker.on('dragend', (evt) => {
            var obj = objects.find((o) => o.obj.uid == evt.target._venus_uid);

            var angle = angleFromCoordinate(
                vessel.position.latitude, vessel.position.longitude,
                //controlMarker.getLatLng().lat, controlMarker.getLatLng().lng,
                this._mousePosition.lat, this._mousePosition.lng,
            );

            this._socket.send(JSON.stringify(
                {
                    "__class__": "ObjectRotateEnd",
                    "object_uid": obj.obj.uid,
                    "new_angle": angle,
                }
            ));
        });

        var rudderPolygons = [];
        for (var i = 0; i < vessel.rudders.length; i++) {
            var rudder = vessel.rudders[i];
            var [start, end] = createRudderPoly(vessel.position, vessel.angle, vessel.size, rudder.angle, rudder.length);

            var rudderPoly = L.polyline([
                start,
                end,
            ])
            .addTo(map);
            rudderPoly.setStyle(rudder.visual_options);

            rudderPolygons.push(rudderPoly);
        }

        if (vessel.data_panel.length > 0) {
            var tooltipContent = propListToHtml(vessel, vessel.data_panel, this._socket);
            poly.bindTooltip(tooltipContent, {
                permanent: true,
                direction: "top",
                interactive: true,
                opacity: 1,
                offset: [0, -20],
                closeOnClick: false,
            });

            poly.closeTooltip();
        }

        poly.on('click', (evt) => {
            if (!hasClassInHierarchy(evt.originalEvent.target, "leaflet-tooltip")) {
                poly.toggleTooltip();
            }
        });

        poly.on('dragstart', (evt) => {
            var obj = objects.find((o) => o.obj.uid == evt.target._venus_uid);

            for (var i = 0; i < obj.visual.rudderPolygons.length; i++) {
                var rudderVisual = obj.visual.rudderPolygons[i];
                rudderVisual.removeFrom(map);
            }

            controlLine.removeFrom(map);
            controlMarker.removeFrom(map);

            this._socket.send(JSON.stringify(
                {
                    "__class__": "ObjectDragStart",
                    "object_uid": obj.obj.uid,
                }
            ));
        });

        var ob = new VenusObject(vessel, new VesselVisual(poly, rudderPolygons, controlMarker, controlLine));

        poly.on('dragend', (evt) => {
            var obj = objects.find((o) => o.obj.uid == evt.target._venus_uid);

            for (var i = 0; i < obj.visual.rudderPolygons.length; i++) {
                var rudderVisual = obj.visual.rudderPolygons[i];
                rudderVisual.addTo(map);
            }

            controlLine.addTo(map);
            controlMarker.addTo(map);

            var controlLineCoords = [
                [this._mousePosition.lat, this._mousePosition.lng],
                latLngFromAngleLength(this._mousePosition.lat, this._mousePosition.lng, vessel.angle, Math.max(vessel.size.width, vessel.size.height) * 0.75),
            ];
            controlLine.setLatLngs(controlLineCoords);
            controlMarker.setLatLng(controlLineCoords[1]);

            this._updateVesselRudders(ob, {'latitude': this._mousePosition.lat, 'longitude': this._mousePosition.lng}, vessel.angle, vessel.size);

            this._socket.send(JSON.stringify(
                {
                    "__class__": "ObjectDragEnd",
                    "object_uid": obj.obj.uid,
                    "new_position": {"latitude": this._mousePosition.lat, "longitude": this._mousePosition.lng},
                }
            ));
        });

        objects.push(ob);
    }

    _updateVesselRudders(oldObj, vesselPosition, vesselAngle, vesselSize) {
        for (var i = 0; i < oldObj.obj.rudders.length; i++) {
            var rudder = oldObj.obj.rudders[i];

            var [start, end] = createRudderPoly(
                vesselPosition,
                vesselAngle,
                vesselSize,
                rudder.angle,
                rudder.length
            );

            oldObj.visual.rudderPolygons[i].setLatLngs([start, end]);
            oldObj.visual.rudderPolygons[i].redraw();
        }
    }

    update(oldObj, updateInfo, map, objects) {
        if (updateInfo.ctx.length == 2) {
            if (updateInfo.ctx[1].prop == "position") {
                var coords = createVesselPoly(updateInfo.value, oldObj.obj.angle, oldObj.obj.size);

                oldObj.visual.vesselPoly.setLatLngs(coords);

                if (oldObj.visual.vesselPoly.getTooltip() != null) {
                    oldObj.visual.vesselPoly.getTooltip().setLatLng([updateInfo.value.latitude, updateInfo.value.longitude]);
                }

                this._updateVesselRudders(oldObj, updateInfo.value, oldObj.obj.angle, oldObj.obj.size);
                
                oldObj.obj.position = updateInfo.value;
            }
            else if (updateInfo.ctx[1].prop == "angle") {
                var coords = createVesselPoly(oldObj.obj.position, updateInfo.value, oldObj.obj.size);

                oldObj.visual.vesselPoly.setLatLngs(coords);

                this._updateVesselRudders(oldObj, oldObj.obj.position, updateInfo.value, oldObj.obj.size);

                oldObj.obj.angle = updateInfo.value;
            }
            else if (updateInfo.ctx[1].prop == "size") {
                var coords = createVesselPoly(oldObj.obj.position, oldObj.obj.angle, updateInfo.value);

                oldObj.visual.vesselPoly.setLatLngs(coords);

                this._updateVesselRudders(oldObj, oldObj.obj.position, oldObj.obj.angle, updateInfo.value);


                oldObj.obj.size = updateInfo.value;
            }
            else if (updateInfo.ctx[1].prop == "visual_options") {
                oldObj.visual.vesselPoly.setStyle(L.extend(Object.assign({}, this._default_vessel_visual_options), updateInfo.value));
                oldObj.obj.visual_options = updateInfo.value;
            }
            else if (updateInfo.ctx[1].prop == "rudders") {
                for (var i = 0; i < oldObj.visual.rudderPolygons.length; i++) {
                    console.log(i);
                    oldObj.visual.rudderPolygons[i].removeFrom(map);
                }

                var rudderPolygons = [];
                for (var i = 0; i < updateInfo.value.length; i++) {
                    var rudder = updateInfo.value[i];
                    var [start, end] = createRudderPoly(oldObj.obj.position, oldObj.obj.angle, oldObj.obj.size, rudder.angle, rudder.length);

                    var rudderPoly = L.polyline([
                        start,
                        end,
                    ])
                    .addTo(map);
                    rudderPoly.setStyle(rudder.visual_options);

                    rudderPolygons.push(rudderPoly);
                }

                oldObj.visual.rudderPolygons = rudderPolygons;
                oldObj.obj.rudders = updateInfo.value;
            }
            else if (updateInfo.ctx[1].prop == "data_panel") {
                var tooltipContent = propListToHtml(oldObj.obj, updateInfo.value, this._socket);
                oldObj.visual.vesselPoly.setTooltipContent(tooltipContent);
                oldObj.visual.vesselPoly.getTooltip().setLatLng([oldObj.obj.position.latitude, oldObj.obj.position.longitude]);
                oldObj.obj.data_panel = updateInfo.value;
            }
            else if (updateInfo.ctx[1].prop == "draggable") {
                if (updateInfo.value) {
                    oldObj.visual.vesselPoly.dragging.enable();
                } else {
                    oldObj.visual.vesselPoly.dragging.disable();
                }
                oldObj.obj.draggable = updateInfo.value;
            }
            else if (updateInfo.ctx[1].prop == "can_rotate") {
                oldObj.obj.can_rotate = updateInfo.value;
                if (oldObj.obj.can_rotate) {
                    oldObj.visual.vesselRotationControlLine.addTo(map);
                    oldObj.visual.vesselRotationControlMarker.addTo(map);
                } else {
                    oldObj.visual.vesselRotationControlLine.removeFrom(map);
                    oldObj.visual.vesselRotationControlMarker.removeFrom(map);
                }
            }
            else {
                console.error("invalid property to update on vessel", updateInfo);
            }
        }
        else if (updateInfo.ctx.length == 3) {
            if (updateInfo.ctx[1].prop == "position") {
                if (updateInfo.ctx[2].prop == "latitude") {
                    var newPos = {
                        latitude: updateInfo.value,
                        longitude: oldObj.obj.position.longitude,
                        altitude: oldObj.obj.position.altitude,
                    };

                    var coords = createVesselPoly(newPos, oldObj.obj.angle, oldObj.obj.size);
                    oldObj.visual.vesselPoly.setLatLngs(coords);

                    if (oldObj.visual.vesselPoly.getTooltip() != null) {
                        oldObj.visual.vesselPoly.getTooltip().setLatLng([updateInfo.value, oldObj.obj.position.longitude]);
                    }

                    this._updateVesselRudders(oldObj, newPos, oldObj.obj.angle, oldObj.obj.size);

                    oldObj.obj.position.latitude = updateInfo.value;
                }
                else if (updateInfo.ctx[2].prop == "longitude") {
                    var newPos = {
                        latitude: oldObj.obj.position.latitude,
                        longitude: updateInfo.value,
                        altitude: oldObj.obj.position.altitude,
                    };

                    var coords = createVesselPoly(newPos, oldObj.obj.angle, oldObj.obj.size);
                    oldObj.visual.vesselPoly.setLatLngs(coords);

                    if (oldObj.visual.vesselPoly.getTooltip() != null) {
                        oldObj.visual.vesselPoly.getTooltip().setLatLng([oldObj.obj.position.latitude, updateInfo.value]);
                    }

                    this._updateVesselRudders(oldObj, newPos, oldObj.obj.angle, oldObj.obj.size);

                    oldObj.obj.position.longitude = updateInfo.value;
                }
                else if (updateInfo.ctx[2].prop == "altitude") {

                }
                else {
                    console.error("invalid property to update on vessel", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "size") {
                if (updateInfo.ctx[2].prop == "width") {
                    var newSize = {
                        width: updateInfo.value,
                        height: oldObj.obj.size.height
                    };

                    var coords = createVesselPoly(oldObj.obj.position, oldObj.obj.angle, newSize);
                    oldObj.visual.vesselPoly.setLatLngs(coords);

                    this._updateVesselRudders(oldObj, oldObj.obj.position, oldObj.obj.angle, newSize);

                    oldObj.obj.size.width = updateInfo.value;
                }
                else if (updateInfo.ctx[2].prop == "height") {
                    var newSize = {
                        width: oldObj.obj.size.width,
                        height: updateInfo.value
                    };

                    var coords = createVesselPoly(oldObj.obj.position, oldObj.obj.angle, newSize);
                    oldObj.visual.vesselPoly.setLatLngs(coords);

                    this._updateVesselRudders(oldObj, oldObj.obj.position, oldObj.obj.angle, newSize);

                    oldObj.obj.size.height = updateInfo.value;
                }
                else {
                    console.error("invalid property to update on vessel", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "visual_options") {
                if (updateInfo.ctx[2].prop != null) {
                    var newVisualOptions = {};
                    newVisualOptions[updateInfo.ctx[2].prop] = updateInfo.value;
                    L.extend(oldObj.obj.visual_options, newVisualOptions);
                    oldObj.visual.vesselPoly.setStyle(oldObj.obj.visual_options);
                } else {
                    console.error("invalid property to update on vessel", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "rudders") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;

                    var [start, end] = createRudderPoly(
                        oldObj.obj.position,
                        oldObj.obj.angle,
                        oldObj.obj.size,
                        updateInfo.value.angle,
                        updateInfo.value.length
                    );

                    var rudderPoly = L.polyline([
                        start,
                        end,
                    ])
                    .addTo(map);
                    rudderPoly.setStyle(updateInfo.value.visual_options);

                    if (oldObj.visual.rudderPolygons[i] == null) {
                        oldObj.visual.rudderPolygons.push(rudderPoly);
                    } else {
                        oldObj.visual.rudderPolygons[i].removeFrom(map);
                        oldObj.visual.rudderPolygons[i] = rudderPoly;
                    }
                    oldObj.obj.rudders[i] = updateInfo.value;
                }
                else {
                    console.error("invalid property to update on vessel", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "data_panel") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;

                    if (oldObj.visual.vesselPoly.getTooltip() == null) {
                        var newPropHtml = propListToHtml(oldObj.obj, [updateInfo.value], this._socket);
                        oldObj.visual.vesselPoly.bindTooltip(newPropHtml, {
                            permanent: true,
                            direction: "top",
                            interactive: true,
                            opacity: 1,
                            offset: [0, -20],
                            closeOnClick: false,
                        });

                        oldObj.visual.vesselPoly.closeTooltip();
                    } else {
                        var newPropHtml = propToHtml(oldObj, updateInfo.value, this._socket);
                        if (i < oldObj.visual.vesselPoly.getTooltip().getContent().children.length) {
                            oldObj.visual.vesselPoly.getTooltip().getContent().children[i].outerHTML = newPropHtml.outerHTML;
                        }
                        else {
                            oldObj.visual.vesselPoly.getTooltip().getContent().appendChild(newPropHtml);
                            oldObj.visual.vesselPoly.getTooltip().setLatLng([oldObj.obj.position.latitude, oldObj.obj.position.longitude]);
                        }
                    }
                    oldObj.obj.data_panel[i] = updateInfo.value;
                }
                else {
                    console.error("invalid property to update on vessel", updateInfo);
                }
            }
            else {
                console.error("invalid property to update on vessel", updateInfo);
            }
        }
        else if (updateInfo.ctx.length == 4) {
            if (updateInfo.ctx[1].prop == "rudders") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;
                    if(updateInfo.ctx[3].prop == "angle") {
                        var rudder = oldObj.obj.rudders[i];

                        var [start, end] = createRudderPoly(
                            oldObj.obj.position,
                            oldObj.obj.angle,
                            oldObj.obj.size,
                            updateInfo.value,
                            rudder.length
                        );

                        oldObj.visual.rudderPolygons[i].setLatLngs([start, end]);
                        oldObj.visual.rudderPolygons[i].redraw();

                        rudder.angle = updateInfo.value;
                    }
                    else if (updateInfo.ctx[3].prop == "length") {
                        var rudder = oldObj.obj.rudders[i];

                        var [start, end] = createRudderPoly(
                            oldObj.obj.position,
                            oldObj.obj.angle,
                            oldObj.obj.size,
                            rudder.angle,
                            updateInfo.value,
                        );

                        oldObj.visual.rudderPolygons[i].setLatLngs([start, end]);
                        oldObj.visual.rudderPolygons[i].redraw();

                        rudder.length = updateInfo.value;
                    }
                    else if (updateInfo.ctx[3].prop == "visual_options") {
                        oldObj.visual.rudderPolygons[i].setStyle(L.extend(Object.assign({}, this._default_rudder_visual_options), updateInfo.value));
                        oldObj.obj.visual_options = updateInfo.value;
                    }
                    else {
                        console.error("invalid property to update on vessel", updateInfo);
                    }
                }
                else {
                    console.error("invalid property to update on vessel", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "data_panel") {
                updateDataPanelObject(updateInfo, oldObj, true);
            }
            else {
                console.error("invalid property to update on vessel", updateInfo);
            }
        }
        else if (updateInfo.ctx.length == 5) {
            if (updateInfo.ctx[1].prop == "rudders") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;
                    if (updateInfo.ctx[3].prop == "visual_options") {
                        if (updateInfo.ctx[4].prop != null) {
                            var newVisualOptions = {};
                            newVisualOptions[updateInfo.ctx[4].prop] = updateInfo.value;
                            L.extend(oldObj.obj.rudders[i].visual_options, newVisualOptions);
                            oldObj.visual.rudderPolygons[i].setStyle(oldObj.obj.rudders[i].visual_options);
                        }
                        else {
                            console.error("invalid property to update on vessel", updateInfo);
                        }
                    }
                    else {
                        console.error("invalid property to update on vessel", updateInfo);
                    }
                }
                else {
                    console.error("invalid property to update on vessel", updateInfo);
                }
            }
            else {
                console.error("invalid property to update on vessel", updateInfo);
            }
        }
        else {
            console.error("invalid property to update on vessel", updateInfo);
        }
    }

    delete_(oldObj, updateInfo, map, objects) {
        if (updateInfo.ctx.length == 3) {
            if (updateInfo.ctx[1].prop == "rudders") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;
                    oldObj.visual.rudderPolygons[i].removeFrom(map);
                    oldObj.visual.rudderPolygons.splice(i, 1);
                    oldObj.obj.rudders.splice(i, 1);
                }
                else {
                    console.error("invalid property to delete on vessel", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "visual_options") {
                if (updateInfo.ctx[2].prop != null) {
                    var propToDelete = updateInfo.ctx[2].prop;
                    delete oldObj.obj.visual_options[propToDelete];
                    oldObj.visual.vesselPoly.setStyle(L.extend(Object.assign({}, this._default_vessel_visual_options), oldObj.obj.visual_options));
                } else {
                    console.error("invalid property to delete on vessel", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "data_panel") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;
                    oldObj.visual.vesselPoly.getTooltip().getContent().children[i].remove();
                    oldObj.obj.data_panel.splice(i, 1);
                    if (oldObj.obj.data_panel.length == 0) {
                        oldObj.visual.vesselPoly.unbindTooltip();
                    } else {
                        oldObj.visual.vesselPoly.getTooltip().setLatLng([oldObj.obj.position.latitude, oldObj.obj.position.longitude]);
                    }
                } else {
                    console.error("invalid property to delete on vessel", updateInfo);
                }
            }
            else {
                console.error("invalid property to delete on vessel", updateInfo);
            }
        }
        else if (updateInfo.ctx.length == 5) {
            if (updateInfo.ctx[1].prop == "rudders") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;
                    if (updateInfo.ctx[3].prop == "visual_options") {
                        if (updateInfo.ctx[4].prop != null) {
                            var propToDelete = updateInfo.ctx[4].prop;
                            delete oldObj.obj.rudders[i].visual_options[propToDelete];
                            oldObj.visual.rudderPolygons[i].setStyle(L.extend(Object.assign({}, this._default_rudder_visual_options), oldObj.obj.rudders[i].visual_options));
                        }
                        else {
                            console.error("invalid property to delete on vessel", updateInfo);
                        }
                    }
                    else {
                        console.error("invalid property to delete on vessel", updateInfo);
                    }
                }
                else {
                    console.error("invalid property to delete on vessel", updateInfo);
                }
            }
            else {
                console.error("invalid property to delete on vessel", updateInfo);
            }
        }
        else {
            console.error("invalid property to delete on vessel", updateInfo);
        }
    }

    remove(vessel, map, objects) {
        vessel.visual.vesselPoly.removeFrom(map);
        vessel.visual.vesselRotationControlMarker.removeFrom(map);
        vessel.visual.vesselRotationControlLine.removeFrom(map);
        for (var i = 0; i < vessel.visual.rudderPolygons.length; i++) {
            vessel.visual.rudderPolygons[i].removeFrom(map);
        }
    }
}