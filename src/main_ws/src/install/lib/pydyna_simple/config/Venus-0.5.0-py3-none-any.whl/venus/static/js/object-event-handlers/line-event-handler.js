"use strict";

class LineEventHandler extends VenusObjectEventHandler {
    constructor(socket, mousePosition) {
        super();
        this._socket = socket;
        this._mousePosition = mousePosition;

        this._default_visual_options = {};
        L.extend(this._default_visual_options, L.Layer.prototype.options);
        L.extend(this._default_visual_options, L.Path.prototype.options);
        L.extend(this._default_visual_options, L.Polyline.prototype.options);
    }

    add(line, map, objects) {
        var coords = line.points.map((p) => [p.latitude, p.longitude]);

        var poly = L.polyline(coords, { smoothFactor: 0, draggable: line.draggable }).addTo(map);
        poly.setStyle(line.visual_options);
        poly._venus_uid = line.uid;

        poly.on('click', (evt) => {
            if (!hasClassInHierarchy(evt.originalEvent.target, "leaflet-tooltip")) {
                poly.toggleTooltip();
                if (poly.getTooltip() != null) {
                    var avg = averageLatLng(
                        poly.getLatLngs().map(
                            (p) => ({
                                "latitude": p.lat,
                                "longitude": p.lng
                            })
                        )
                    );
                    poly.getTooltip().setLatLng([avg.latitude, avg.longitude]);
                }
            }
        });

        if (line.data_panel.length > 0) {
            var tooltipContent = propListToHtml(line, line.data_panel, this._socket);
            poly.bindTooltip(tooltipContent, {
                permanent: true,
                direction: "top",
                interactive: true,
                opacity: 1,
                offset: [0, -20],
                closeOnClick: false,
            });

            poly.closeTooltip();
        }

        poly.on('dragstart', (evt) => {
            var obj = objects.find((o) => o.obj.uid == evt.target._venus_uid);
            this._socket.send(JSON.stringify(
                {
                    "__class__": "ObjectDragStart",
                    "object_uid": obj.obj.uid,
                }
            ));
        });

        poly.on('dragend', (evt) => {
            var obj = objects.find((o) => o.obj.uid == evt.target._venus_uid);
            this._socket.send(JSON.stringify(
                {
                    "__class__": "ObjectDragEnd",
                    "object_uid": obj.obj.uid,
                    "new_position": {"latitude": this._mousePosition.lat, "longitude": this._mousePosition.lng},
                }
            ));
        });

        objects.push(new VenusObject(line, poly));
    }

    update(oldObj, updateInfo, map, objects) {
        if (updateInfo.ctx.length == 2) {
            if (updateInfo.ctx[1].prop == "points") {
                oldObj.visual.setLatLngs(updateInfo.value.map(v => [v.latitude, v.longitude]));

                if (oldObj.visual.getTooltip() != null) {
                    var avg = averageLatLng(oldObj.obj.points);
                    oldObj.visual.getTooltip().setLatLng([avg.latitude, avg.longitude]);
                }

                oldObj.obj.points = updateInfo.value;
            }
            else if (updateInfo.ctx[1].prop == "visual_options") {
                oldObj.visual.setStyle(L.extend(Object.assign({}, this._default_visual_options), updateInfo.value));
                oldObj.obj.visual_options = updateInfo.value;
            }
            else if (updateInfo.ctx[1].prop == "data_panel") {
                var tooltipContent = propListToHtml(oldObj.obj, updateInfo.value, this._socket);
                oldObj.visual.setTooltipContent(tooltipContent);
                var avg = averageLatLng(oldObj.obj.points);
                oldObj.visual.getTooltip().setLatLng([avg.latitude, avg.longitude]);
                oldObj.obj.data_panel = updateInfo.value;
            }
            else if (updateInfo.ctx[1].prop == "draggable") {
                if (updateInfo.value) {
                    oldObj.visual.dragging.enable();
                } else {
                    oldObj.visual.dragging.disable();
                }
                oldObj.obj.draggable = updateInfo.value;
            }
            else {
                console.error("invalid property to update on line", updateInfo);
            }
        }
        else if (updateInfo.ctx.length == 3) {
            if (updateInfo.ctx[1].prop == "points") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;

                    if (i < oldObj.obj.points.length) {
                        oldObj.obj.points[i].latitude = updateInfo.value.latitude;
                        oldObj.obj.points[i].longitude = updateInfo.value.latitude;
                    } else {
                        oldObj.obj.points.push(updateInfo.value);
                    }

                    oldObj.visual.setLatLngs(oldObj.obj.points.map(v => [v.latitude, v.longitude]));

                    if (oldObj.visual.getTooltip() != null) {
                        var avg = averageLatLng(oldObj.obj.points);
                        oldObj.visual.getTooltip().setLatLng([avg.latitude, avg.longitude]);
                    }

                } else {
                    console.error("invalid property to update on line", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "visual_options") {
                if (updateInfo.ctx[2].prop != null) {
                    var newVisualOptions = {};
                    newVisualOptions[updateInfo.ctx[2].prop] = updateInfo.value;
                    L.extend(oldObj.obj.visual_options, newVisualOptions);
                    oldObj.visual.setStyle(oldObj.obj.visual_options);
                } else {
                    console.error("invalid property to update on line", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "data_panel") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;
                    if (oldObj.visual.getTooltip() == null) {
                        var newPropHtml = propListToHtml(oldObj.obj, [updateInfo.value], this._socket);
                        oldObj.visual.bindTooltip(newPropHtml, {
                            permanent: true,
                            direction: "top",
                            interactive: true,
                            opacity: 1,
                            offset: [0, -20],
                            closeOnClick: false,
                        });

                        var avg = averageLatLng(oldObj.obj.points);
                        oldObj.visual.getTooltip().setLatLng([avg.latitude, avg.longitude]);

                        oldObj.visual.closeTooltip();
                    } else {
                        var newPropHtml = propToHtml(oldObj, updateInfo.value, this._socket);
                        if (i < oldObj.visual.getTooltip().getContent().children.length) {
                            oldObj.visual.getTooltip().getContent().children[i].outerHTML = newPropHtml.outerHTML;
                        }
                        else {
                            oldObj.visual.getTooltip().getContent().appendChild(newPropHtml);
                            var avg = averageLatLng(oldObj.obj.points);
                            oldObj.visual.getTooltip().setLatLng([avg.latitude, avg.longitude]);
                        }
                    }
                    oldObj.obj.data_panel[i] = updateInfo.value;
                }
                else {
                    console.error("invalid property to update on beacon", updateInfo);
                }
            }
            else {
                console.error("invalid property to update on line", updateInfo);
            }
        }
        else if (updateInfo.ctx.length == 4) {
            if (updateInfo.ctx[1].prop == "points") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;
                    if (updateInfo.ctx[3].prop == "latitude") {
                        var newPoints = oldObj.obj.points.map(v => [v.latitude, v.longitude]);
                        newPoints[i] = [updateInfo.value, newPoints[i][1]];
                        oldObj.visual.setLatLngs(newPoints);

                        if (oldObj.visual.getTooltip() != null) {
                            var avg = averageLatLng(oldObj.obj.points);
                            oldObj.visual.getTooltip().setLatLng([avg.latitude, avg.longitude]);
                        }

                        oldObj.obj.points[i] = {
                            __class__: "GeoPos",
                            latitude: newPoints[i][0],
                            longitude: newPoints[i][1],
                        }
                    }
                    else if (updateInfo.ctx[3].prop == "longitude") {
                        var newPoints = oldObj.obj.points.map(v => [v.latitude, v.longitude]);
                        newPoints[i] = [newPoints[i][0], updateInfo.value];
                        oldObj.visual.setLatLngs(newPoints);

                        if (oldObj.visual.getTooltip() != null) {
                            var avg = averageLatLng(oldObj.obj.points);
                            oldObj.visual.getTooltip().setLatLng([avg.latitude, avg.longitude]);
                        }

                        oldObj.obj.points[i] = {
                            __class__: "GeoPos",
                            latitude: newPoints[i][0],
                            longitude: newPoints[i][1],
                        }
                    }
                    else {
                        console.error("invalid property to update on line", updateInfo);
                    }
                }
                else {
                    console.error("invalid property to update on line", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "data_panel") {
                updateDataPanelObject(updateInfo, oldObj, true);
            }
            else {
                console.error("invalid property to update on line", updateInfo);
            }
        }
        else {
            console.error("invalid property to update on line", updateInfo);
        }
    }

    delete_(oldObj, updateInfo, map, objects) {
        if (updateInfo.ctx.length == 3) {
            if (updateInfo.ctx[1].prop == "points") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;
                    oldObj.obj.points.splice(i, 1);
                    oldObj.visual.setLatLngs(oldObj.obj.points.map(p => [p.latitude, p.longitude]));

                    if (oldObj.visual.getTooltip() != null) {
                        var avg = averageLatLng(oldObj.obj.points);
                        oldObj.visual.getTooltip().setLatLng([avg.latitude, avg.longitude]);
                    }
                }
                else {
                    console.error("invalid property to delete on line", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "visual_options") {
                if (updateInfo.ctx[2].prop != null) {
                    var propToDelete = updateInfo.ctx[2].prop;
                    delete oldObj.obj.visual_options[propToDelete];
                    oldObj.visual.setStyle(L.extend(Object.assign({}, this._default_visual_options), oldObj.obj.visual_options));
                } else {
                    console.error("invalid property to delete on line", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "data_panel") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;
                    oldObj.visual.getTooltip().getContent().children[i].remove();
                    oldObj.obj.data_panel.splice(i, 1);
                    if (oldObj.obj.data_panel.length == 0) {
                        oldObj.visual.unbindTooltip();
                    } else {
                        var avg = averageLatLng(oldObj.obj.points);
                        oldObj.visual.getTooltip().setLatLng([avg.latitude, avg.longitude]);
                    }
                } else {
                    console.error("invalid property to delete on line", updateInfo);
                }
            }
            else {
                console.error("invalid property to delete on line", updateInfo);
            }
        }
        else {
            console.error("invalid property to delete on line", updateInfo);
        }
    }

    remove(line, map, objects) {
        line.visual.removeFrom(map);
    }
}