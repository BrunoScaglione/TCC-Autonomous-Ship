"use strict";

class ArrowVisual {
    constructor(body, head) {
        this.body = body;
        this.head = head;
    }

    setStyle(style) {
        this.body.setStyle(style);
        this.head.setStyle(style);
    }

    setLatLngs(latLngs) {
        this.body.setLatLngs(latLngs);
        this.head.setPaths(latLngs);
    }
}

class ArrowEventHandler extends VenusObjectEventHandler {
    constructor() {
        super();

        this._default_visual_options = {};
        L.extend(this._default_visual_options, L.Layer.prototype.options);
        L.extend(this._default_visual_options, L.Path.prototype.options);
        L.extend(this._default_visual_options, L.Polyline.prototype.options);
    }

    add(arrow, map, objects) {
        var arrowEnd = latLngFromAngleLength(arrow.position.latitude, arrow.position.longitude, arrow.angle, arrow.length);
        var poly = L.polyline([
            [arrow.position.latitude, arrow.position.longitude],
            arrowEnd,
        ]).addTo(map);
        poly.setStyle(arrow.visual_options);
        var arrowHead = L.polylineDecorator(poly, {
            patterns: [
                {
                    offset: '100%',
                    repeat: 0,
                    symbol: L.Symbol.arrowHead({pixelSize: 15, polygon: false, pathOptions: {stroke: true}})
                }
            ]
        }).addTo(map);
        arrowHead.setStyle(arrow.visual_options);

        objects.push(new VenusObject(arrow, new ArrowVisual(poly, arrowHead)));
    }

    _updateVisuals(oldObj, lat, lng, angle, length) {
        var arrowEnd = latLngFromAngleLength(lat, lng, angle, length);
        oldObj.visual.setLatLngs([
            [lat, lng],
            arrowEnd
        ]);
    }

    _contextToObjectKey(ctxPart) {
        if (ctxPart.prop != null) {
            return ctxPart.prop;
        } else if (ctxPart.i != null) {
            return ctxPart.i;
        } else {
            throw new Error("Invalid context part object");
        }
    }

    _updatePropertyFromContext(obj, context, value) {
        var cur = obj;
        for(var i = 1; i < context.length - 1; i++) {
            cur = cur[this._contextToObjectKey(context[i])];
        }
        cur[this._contextToObjectKey(context[context.length-1])] = value;
    }

    update(oldObj, updateInfo, map, objects) {
        if (updateInfo.ctx.length == 2) {
            if (updateInfo.ctx[1].prop == "position") {
                this._updateVisuals(oldObj, updateInfo.value.latitude, updateInfo.value.longitude, oldObj.obj.angle, oldObj.obj.length);
            }
            else if (updateInfo.ctx[1].prop == "angle") {
                this._updateVisuals(oldObj, oldObj.obj.position.latitude, oldObj.obj.position.longitude, updateInfo.value, oldObj.obj.length);
            }
            else if (updateInfo.ctx[1].prop == "length") {
                this._updateVisuals(oldObj, oldObj.obj.position.latitude, oldObj.obj.position.longitude, oldObj.obj.angle, updateInfo.value);
            }
            else if (updateInfo.ctx[1].prop == "visual_options") {
                oldObj.visual.setStyle(L.extend(Object.assign({}, this._default_visual_options), updateInfo.value));
            }
            else {
                console.error("invalid property to update on arrow", updateInfo);
            }
        }
        else if (updateInfo.ctx.length == 3) {
            if (updateInfo.ctx[1].prop == "position") {
                if (updateInfo.ctx[2].prop == "latitude") {
                    this._updateVisuals(oldObj, updateInfo.value, oldObj.obj.position.longitude, oldObj.obj.angle, oldObj.obj.length);
                }
                else if (updateInfo.ctx[2].prop == "longitude") {
                    this._updateVisuals(oldObj, oldObj.obj.position.latitude, updateInfo.value, oldObj.obj.angle, oldObj.obj.length);
                }
                else {
                    console.error("invalid property to update on arrow", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "visual_options") {
                if (updateInfo.ctx[2].prop != null) {
                    var newVisualOptions = {};
                    newVisualOptions[updateInfo.ctx[2].prop] = updateInfo.value;
                    L.extend(oldObj.obj.visual_options, newVisualOptions);
                    oldObj.visual.setStyle(oldObj.obj.visual_options);
                } else {
                    console.error("invalid property to update on arrow", updateInfo);
                }
            }
            else {
                console.error("invalid property to update on arrow", updateInfo);
            }
        }
        else {
            console.error("invalid property to update on arrow", updateInfo);
        }

        this._updatePropertyFromContext(oldObj.obj, updateInfo.ctx, updateInfo.value);
    }

    delete_(oldObj, updateInfo, map, objects) {
        if (updateInfo.ctx.length == 3) {
            if (updateInfo.ctx[1].prop == "visual_options") {
                if (updateInfo.ctx[2].prop != null) {
                    var propToDelete = updateInfo.ctx[2].prop;
                    delete oldObj.obj.visual_options[propToDelete];
                    oldObj.visual.setStyle(L.extend(Object.assign({}, this._default_visual_options), oldObj.obj.visual_options));
                } else {
                    console.error("invalid property to delete on arrow", updateInfo);
                }
            }
            else {
                console.error("invalid property to delete on arrow", updateInfo);
            }
        }
        else {
            console.error("invalid property to delete on arrow", updateInfo);
        }
    }

    remove(arrow, map, objects) {
        arrow.visual.head.removeFrom(map);
        arrow.visual.body.removeFrom(map);
    }
}