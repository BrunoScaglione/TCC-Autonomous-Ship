from venus.objects import GeoPos
from typing import Optional
from geographiclib.geodesic import Geodesic, Constants
from math import atan2, sqrt, pow, pi

_geodesic = Geodesic(Constants.WGS84_a, Constants.WGS84_f)


class RelPos:
    """
    The `RelPost` class exists to make it easier to create "relative positions". When you have
    an absolute position using latitude and longitude coordinates you can use this class to find
    another latitude/longitude pair that's x meters far away from the absolute position.

    There are three ways you can define an absolute position for your RelPos instances. You can
    call the static method `RelPos.set_absolute_position` to globally define it. You can add one
    to the RelPos instance and you can define one only when turning the RelPos into a GeoPos.

    #### Static methods

    - `set_absolute_position(position: GeoPos)`: Sets a global absolute position.

    #### Methods

    - `to_geo(absolute_position: Optional[GeoPos]) -> GeoPos`: Transforms a relative position into a
    georeferenced one. If none of the methods to set an absolute position is used and the `absolute_position`
    parameter is none a `RuntimeError` is raised.

    #### Examples

    Find a georeferenced position 20 meters away from a central position:

    ```python
    absolute = GeoPos(23, 45)
    relative = RelPos(20, 0).to_geo(absolute)
    ```

    Find a georeferenced position for many points:

    ```python
    absolute = GeoPos(23, 45)
    RelPos.set_absolute_position(absolute)

    points = [RelPos(i, i).to_geo() for i in range(0, 20)]
    ```

    """

    _absolute_position = None  # type: GeoPos

    def __init__(self, x: float, y: float, absolute_position: Optional[GeoPos] = None):
        self.x = x
        self.y = y
        self.absolute_position = absolute_position

    def to_geo(self, absolute_position: Optional[GeoPos] = None) -> GeoPos:
        """
        Transforma essa instância de RelPos em uma posição georreferênciada.
        Caso o parâmetro `absolute_position` seja `None`, tenta-se utilizar
        o `absolute_position` da instância. Se esse também não existir, é
        necessário utilizar o método estático `set_absolute_position` para
        definir uma posição absoluta global. Se nenhuma dessas posições existir
        esse método lança um `RuntimeError`.
        """
        if absolute_position is None:
            if self.absolute_position is not None:
                absolute_position = self.absolute_position
            elif RelPos._absolute_position is not None:
                absolute_position = RelPos._absolute_position
            else:
                raise RuntimeError(
                    (
                        "Cannot convert a relative position to geographic without an absolute position as a reference."
                        "\n"
                        "Possible fixes:\n"
                        "1) Call `to_geo` with the `absolute_position` parameter.\n"
                        "2) Create the `RelPos` instance with the `absolute_position` parameter.\n"
                        "3) Call `RelPos.set_absolute_position`."
                    )
                )

        azimuth = atan2(self.x, self.y) * 180 / pi
        distance = sqrt(pow(self.x, 2) + pow(self.y, 2))

        geo_result = _geodesic.Direct(
            absolute_position.latitude, absolute_position.longitude, azimuth, distance
        )

        return GeoPos(geo_result["lat2"], geo_result["lon2"])

    @staticmethod
    def set_absolute_position(absolute_position: GeoPos):
        RelPos._absolute_position = absolute_position
