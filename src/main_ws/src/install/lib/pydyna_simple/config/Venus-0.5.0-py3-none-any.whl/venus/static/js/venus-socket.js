"use strict";

class VenusSocket {
    constructor(addr){
        this.socket = new ReconnectingWebSocket(addr);
        this.socket.onopen = this.onSocketOpen.bind(this);
        this.socket.onmessage = this.onSocketMessage.bind(this);
        this.socket.onclose = this.onSocketClose.bind(this);
        this.socket.onerror = this.onSocketError.bind(this);

        this.socket.onconnecting = function(ev) {
            document.getElementById("connection-lost").style.display = "block";
        }
    }

    onConnectionSuccess(msg){}
    onViewportChange(msg){}
    onViewportCenterChange(msg){}
    onViewportZoomChange(msg){}
    onGeographicBaseChange(msg){}
    onObjectAdded(msg){}
    onObjectUpdated(msg){}
    onObjectRemoved(msg){}
    onDelete(msg){}

    send(message) {
        this.socket.send(message);
    }

    onSocketOpen() {
        document.getElementById("connection-lost").style.display = "none";
    }

    onSocketMessage(ev) {
        var parsedEv = null;
        try {
            parsedEv = JSON.parse(ev.data);
            //console.log(parsedEv);
        } catch (e) {
            throw new VenusMessageParseError("Invalid message received: " + ev.data + " | " + e);
        }
        if (parsedEv.__class__ != undefined) {
            if (parsedEv.__class__ == "ConnectionSuccess") {
                this.onConnectionSuccess(parsedEv);
            } else if (parsedEv.__class__ == "ViewportChange") {
                this.onViewportChange(parsedEv);
            } else if (parsedEv.__class__ == "Added") {
                this.onObjectAdded(parsedEv.value);
            } else if (parsedEv.__class__ == "Updated") {
                this.onObjectUpdated(parsedEv);
            } else if (parsedEv.__class__ == "Deleted") {
                this.onDelete(parsedEv);
            } else if (parsedEv.__class__ == "Removed") {
                this.onObjectRemoved(parsedEv);
            } else if (parsedEv.__class__ == "StartRecording") {
                navigator.mediaDevices.getDisplayMedia({
                    "cursor": "never",
                    "displaySurface": "application",
                }).then(async (stream) => {
                    if (stream != null) {
                        this.stream = stream;
                        this.recorder = RecordRTC(stream, {
                            type: 'video'
                        });
                        this.recorder.startRecording();
                    }
                });
            } else if (parsedEv.__class__ == "StopRecording") {
                if (this.recorder != null) {
                    this.recorder.stopRecording(() => {
                        var blob = this.recorder.getBlob();
                        invokeSaveAsDialog(blob);
                        this.recorder.destroy();
                        this.stream.getTracks().forEach(track => track.stop())
                    });
                }
            } else {
                throw new VenusMessageParseError("Invalid message received: " + ev.data);
            }
        } else {
            throw new VenusMessageParseError("Invalid message received: " + ev.data);
        }
    }

    onSocketClose(ev) {
        //console.warn("Socket closed: ", ev);
    }

    onSocketError(ev) {
        //console.warn("Socket error: ", ev);
    }
}