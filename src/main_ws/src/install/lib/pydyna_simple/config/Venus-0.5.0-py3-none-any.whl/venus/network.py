from venus.evented import EventedObject, Uid, Property, ArrayElement, Primitives
from typing import Callable, Optional, Any
import json


"""
`Added`, `Updated`, `Deleted` e `Removed` são os eventos possíveis que o frontend 
recebe.
"""


class Added:
    """
    `Added` é enviado sempre que um objeto novo é adicionado com `Venus.add`.
    """
    def __init__(self, value):
        self.value = value


class Updated:
    """
    `Updated` é enviado sempre que uma propriedade de um objeto é alterada.
    """
    def __init__(self, ctx, value):
        self.ctx = ctx
        self.value = value


class Deleted:
    """
    `Deleted` é enviado sempre que um elemento de um dicionário ou de uma lista são apagados.
    """
    def __init__(self, ctx):
        self.ctx = ctx


class Removed:
    """
    `Removed` é enviado sempre que um objeto é removido utilizado `Venus.remove`.
    """
    def __init__(self, uid):
        self.uid = uid


def serialize(value):
    """
    A função `serialize` tenta serializar qualquer tipo de objeto lendo suas propriedades
    utilizando reflection. Ela possui conhecimento de alguns outros tipos do Venus e trata
    eles de forma especial.
    """
    if isinstance(value, (Uid, Property, ArrayElement)):
        return value.as_dict()
    elif isinstance(value, list):
        ret = []
        for v in value:
            ret.append(serialize(v))
        return ret
    elif isinstance(value, dict):
        ret = {}
        for k in value.keys():
            ret[k] = serialize(value[k])
        return ret
    elif isinstance(value, Primitives):
        return value
    elif value is None:
        return None
    else:
        ret = {"__class__": value.__class__.__name__}
        # Alguns objetos possuem uma propriedade `uid`, outros possuem um método `uid`.
        # Caso o objeto possua o método precisamos chamá-lo explicitamente.
        if hasattr(value, "uid"):
            if isinstance(value.uid, Callable):
                ret["uid"] = value.uid()
        try:
            for k in value.__dict__:
                if k.startswith("_"):
                    continue
                ret[k] = serialize(value.__getattribute__(k))
        except AttributeError:
            print(value)
        return ret


class NetworkObject:
    _global_uid = 0  # type: int

    def __new__(cls, *args, **kwargs):
        instance = object.__new__(cls)
        instance.__init__(*args, **kwargs)
        return EventedObject(
            instance, [Uid(instance.__uid)], instance._on_change, instance._on_delete
        )

    def __init__(self):
        self.__server = None  # type: Optional[Any]
        self.__uid = NetworkObject._global_uid  # type: int
        NetworkObject._global_uid += 1

    def uid(self):
        return self.__uid

    def _on_change(self, ctx, value):
        if self.__server is not None:
            msg = json.dumps(serialize(Updated(ctx, value)))
            self.__server.broadcast(msg)

    def _on_delete(self, ctx):
        if self.__server is not None:
            msg = json.dumps(serialize(Deleted(ctx)))
            self.__server.broadcast(msg)

    def set_server(self, server: Optional[Any]):
        self.__server = server

    def __repr__(self):
        return f"NetworkObject(id: {self.__uid})"

    def __eq__(self, other):
        if isinstance(other, NetworkObject):
            return self.__uid == other.__uid
        else:
            return False

    def __hash__(self):
        return hash(self.__uid)
