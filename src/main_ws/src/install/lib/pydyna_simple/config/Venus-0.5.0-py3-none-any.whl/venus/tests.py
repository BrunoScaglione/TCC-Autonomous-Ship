from venus.objects import *
from time import sleep
from math import sin, cos, pi, radians


def test_array(obj, array_name, el1, el2, el3, el4, el5, el6, func):
    getattr(obj, array_name).append(el1)
    getattr(obj, array_name).extend([el2, el3])
    getattr(obj, array_name).insert(3, el4)
    sleep(2)
    getattr(obj, array_name).clear()
    sleep(2)
    getattr(obj, array_name).append(el1)
    sleep(2)
    getattr(obj, array_name).extend([el2, el3])
    sleep(2)
    getattr(obj, array_name).insert(3, el4)
    sleep(2)
    getattr(obj, array_name).remove(el1)
    sleep(2)
    getattr(obj, array_name).pop()
    sleep(2)
    getattr(obj, array_name).reverse()
    sleep(2)
    getattr(obj, array_name).pop(0)
    sleep(2)
    setattr(obj, array_name, [el5, el6])
    sleep(2)
    func(getattr(obj, array_name))
    sleep(2)
    getattr(obj, array_name).clear()
    sleep(2)


def test_data_panel(panel1):
    def func(arr):
        arr[0].key += "*"
        arr[-1].name += "*"

    test_array(
        panel1,
        "data_panel",
        KeyValue("1", "1"),
        KeyValue("2", "2"),
        KeyValue("3", "3"),
        KeyValue("4", "4"),
        KeyValue("5", "5"),
        Button("6", "6"),
        func,
    )


def test_add_remove(venus):
    pos = RelPos(0, 0).to_geo()
    objs = [
        venus.add(Arrow(pos, 0, 100, {"color": "purple"})),
        venus.add(Beacon(pos, [KeyValue("a", "a")], {"color": "purple"})),
        venus.add(
            Line(
                [RelPos(-100, 0).to_geo(), RelPos(100, 0).to_geo()],
                [KeyValue("a", "a")],
                {"color": "purple"},
            )
        ),
        venus.add(Panel([])),
        venus.add(
            Polygon(
                [
                    RelPos(-100, 0).to_geo(),
                    RelPos(100, 0).to_geo(),
                    RelPos(0, 100).to_geo(),
                ],
                [KeyValue("a", "a")],
                {"color": "purple"},
            )
        ),
        venus.add(
            Vessel(
                pos,
                0,
                Size(100, 100),
                [
                    Rudder(45, 0.1, {"color": "purple"}),
                    Rudder(180, 0.1, {"color": "purple"}),
                ],
                [KeyValue("a", "a")],
                {"color": "purple"},
            )
        ),
    ]

    sleep(2)

    for obj in objs:
        venus.remove(obj)


def test_arrow(venus, central_position):
    arrow1 = venus.add(Arrow(central_position, 0, 100, {}))
    sleep(2)
    arrow1.position = RelPos(100, 100).to_geo()
    arrow1.angle = 180
    arrow1.length = 200
    arrow1.visual_options = {"color": "green"}
    sleep(2)
    new_pos = RelPos(-100, -100).to_geo()
    arrow1.position.latitude = new_pos.latitude
    arrow1.position.longitude = new_pos.longitude
    arrow1.visual_options["color"] = "red"
    sleep(2)
    arrow1.visual_options.popitem()
    sleep(2)
    arrow1.visual_options.update({"color": "blue"})
    sleep(2)
    arrow1.visual_options.clear()
    sleep(2)
    venus.remove(arrow1)
    sleep(2)


def test_panel(venus):
    panel1 = venus.add(Panel([]))
    sleep(2)
    test_data_panel(panel1)
    sleep(2)
    venus.remove(panel1)
    sleep(2)


def test_beacon(venus, central_position):
    beacon1 = venus.add(Beacon(central_position, [], {}))
    sleep(2)
    beacon1.position = RelPos(100, 100).to_geo()
    beacon1.visual_options = {"background-color": "green"}
    sleep(2)
    new_pos = RelPos(-100, -100).to_geo()
    beacon1.position.latitude = new_pos.latitude
    beacon1.position.longitude = new_pos.longitude
    beacon1.visual_options["background-color"] = "red"
    sleep(2)
    beacon1.visual_options.popitem()
    sleep(2)
    beacon1.visual_options.update({"background-color": "blue"})
    sleep(2)
    test_data_panel(beacon1)
    beacon1.visual_options.clear()
    sleep(2)
    venus.remove(beacon1)
    sleep(2)


def test_polygon(venus):
    polygon1 = venus.add(
        Polygon(
            points=[
                RelPos(sin(radians(n)) * 400, cos(radians(n)) * 400).to_geo()
                for n in range(0, 360, int(360 / 32))
            ],
            visual_options={},
            data_panel=[],
        )
    )
    sleep(2)
    polygon1.points = [
        RelPos(sin(radians(n)) * 400, cos(radians(n)) * 400).to_geo()
        for n in range(0, 360, int(360 / 6))
    ]
    polygon1.visual_options = {"color": "green"}
    sleep(2)
    new_points = [
        RelPos(sin(radians(n)) * 400, cos(radians(n)) * 400).to_geo()
        for n in range(0, 360, int(360 / 4))
    ]
    polygon1.points.pop()
    sleep(2)
    polygon1.points.pop()
    sleep(2)
    polygon1.points[0].latitude = new_points[0].latitude
    polygon1.points[0].longitude = new_points[0].longitude
    polygon1.points[1].latitude = new_points[1].latitude
    polygon1.points[1].longitude = new_points[1].longitude
    polygon1.points[2].latitude = new_points[2].latitude
    polygon1.points[2].longitude = new_points[2].longitude
    polygon1.points[3].latitude = new_points[3].latitude
    polygon1.points[3].longitude = new_points[3].longitude
    sleep(2)
    polygon1.visual_options["color"] = "red"
    sleep(2)
    polygon1.visual_options.popitem()
    sleep(2)
    polygon1.visual_options.update({"color": "blue"})
    sleep(2)
    polygon1.points.clear()
    sleep(2)
    new_points_hex = [
        RelPos(sin(radians(n)) * 400, cos(radians(n)) * 400).to_geo()
        for n in range(0, 360, int(360 / 6))
    ]

    def func(arr):
        arr[0] = GeoPos(arr[0].longitude, arr[0].latitude)
        arr[-1] = GeoPos(arr[-1].longitude, arr[-1].latitude)

    test_array(
        polygon1,
        "points",
        new_points_hex[0],
        new_points_hex[1],
        new_points_hex[2],
        new_points_hex[3],
        new_points_hex[4],
        new_points_hex[5],
        func,
    )
    sleep(2)
    polygon1.points = new_points_hex
    sleep(2)
    test_data_panel(polygon1)
    polygon1.visual_options.clear()
    sleep(2)
    venus.remove(polygon1)
    sleep(2)


def test_line(venus):
    line1 = venus.add(
        Line(
            points=[
                RelPos(sin(radians(n)) * 400, cos(radians(n)) * 400).to_geo()
                for n in range(0, 360, int(360 / 32))
            ],
            visual_options={},
            data_panel=[],
        )
    )
    sleep(2)
    line1.points = [
        RelPos(sin(radians(n)) * 400, cos(radians(n)) * 400).to_geo()
        for n in range(0, 360, int(360 / 6))
    ]
    line1.visual_options = {"color": "green"}
    sleep(2)
    new_points = [
        RelPos(sin(radians(n)) * 400, cos(radians(n)) * 400).to_geo()
        for n in range(0, 360, int(360 / 4))
    ]
    line1.points.pop()
    sleep(2)
    line1.points.pop()
    sleep(2)
    line1.points[0].latitude = new_points[0].latitude
    line1.points[0].longitude = new_points[0].longitude
    line1.points[1].latitude = new_points[1].latitude
    line1.points[1].longitude = new_points[1].longitude
    line1.points[2].latitude = new_points[2].latitude
    line1.points[2].longitude = new_points[2].longitude
    line1.points[3].latitude = new_points[3].latitude
    line1.points[3].longitude = new_points[3].longitude
    sleep(2)
    line1.visual_options["color"] = "red"
    sleep(2)
    line1.visual_options.popitem()
    sleep(2)
    line1.visual_options.update({"color": "blue"})
    sleep(2)
    line1.points.clear()
    sleep(2)
    new_points_hex = [
        RelPos(sin(radians(n)) * 400, cos(radians(n)) * 400).to_geo()
        for n in range(0, 360, int(360 / 6))
    ]

    def func(arr):
        arr[0] = GeoPos(arr[0].longitude, arr[0].latitude)
        arr[-1] = GeoPos(arr[-1].longitude, arr[-1].latitude)

    test_array(
        line1,
        "points",
        new_points_hex[0],
        new_points_hex[1],
        new_points_hex[2],
        new_points_hex[3],
        new_points_hex[4],
        new_points_hex[5],
        func,
    )
    sleep(2)
    line1.points = new_points_hex
    sleep(2)
    test_data_panel(line1)
    line1.visual_options.clear()
    sleep(2)
    venus.remove(line1)
    sleep(2)


def test_vessel(venus, central_position):
    vessel1 = venus.add(Vessel(central_position, 0, Size(50, 200), [], [], {}))
    #sleep(2)
    vessel1.position = central_position.relative(100, 100)
    vessel1.angle = 45
    vessel1.size.width = 200
    vessel1.size.height = 50
    #sleep(2)
    vessel1.size = Size(50, 200)
    new_pos = central_position.relative(-100, -100)
    vessel1.position.latitude = new_pos.latitude
    vessel1.position.longitude = new_pos.longitude
    #sleep(2)
    vessel1.rudders.append(Rudder(0, 1, {}))
    #sleep(2)
    vessel1.rudders[0].angle = 180
    vessel1.rudders[0].length = 0.1
    vessel1.rudders[0].visual_options = {"color": "green"}
    vessel1.visual_options = {"color": "green"}
    #sleep(2)
    vessel1.rudders[0].visual_options["color"] = "red"
    vessel1.visual_options["color"] = "red"
    #sleep(2)
    vessel1.rudders[0].visual_options.popitem()
    vessel1.visual_options.popitem()
    #sleep(2)
    vessel1.rudders[0].visual_options.update({"color": "blue"})
    vessel1.visual_options.update({"color": "blue"})
    #sleep(2)
    #test_data_panel(vessel1)
    vessel1.rudders[0].visual_options.clear()
    vessel1.visual_options.clear()
    #sleep(2)
    vessel1.rudders.pop()
    #sleep(2)

    def func(arr):
        arr[0].angle *= -1
        arr[1].angle *= -1

    test_array(
        vessel1,
        "rudders",
        Rudder(0, 0.1, {"color": "red"}),
        Rudder(45, 0.1, {"color": "orange"}),
        Rudder(90, 0.1, {"color": "yellow"}),
        Rudder(135, 0.1, {"color": "purple"}),
        Rudder(180, 0.1, {"color": "blue"}),
        Rudder(225, 0.1, {"color": "green"}),
        func,
    )
    sleep(2)
    venus.remove(vessel1)
    sleep(2)


def run_tests(venus, central_position: GeoPos):
    while True:
        sleep(5)

        test_add_remove(venus)

        test_arrow(venus, central_position)
        test_panel(venus)
        test_beacon(venus, central_position)
        test_polygon(venus)
        test_vessel(venus, central_position)
        test_line(venus)
