"use strict";

class GeotiffEventHandler extends VenusObjectEventHandler {
    constructor() {
        super();
    }

    add(geotiff, map, objects) {
        var min = [geotiff.bounds.min.latitude, geotiff.bounds.min.longitude];
        var max = [geotiff.bounds.max.latitude, geotiff.bounds.max.longitude];

        var img = L.imageOverlay(geotiff.url, [min, max]).addTo(map);
        objects.push(new VenusObject(geotiff, img));
    }

    remove(geotiff, map, objects) {
        geotiff.visual.removeFrom(map);
    }
}