"use strict";

function VenusMessageParseError(error_message) {
    this.message = error_message;
    this.stack = (new Error()).stack;
}

VenusMessageParseError.prototype = Object.create(Error.prototype);
VenusMessageParseError.prototype.name = "VenusMessageParseError";
VenusMessageParseError.prototype.constructor = VenusMessageParseError;


function toRadians (angleDeg) {
    return angleDeg * (Math.PI / 180);
}

function toDegrees (angleRad) {
    return angleRad * 180 / Math.PI;
}

function latLngFromDistance(baseLatitude, baseLongitude, distanceInMetersX, distanceInMetersY) {
    var azi = toDegrees(Math.atan2(distanceInMetersX, distanceInMetersY));
    var distance = Math.sqrt(Math.pow(distanceInMetersX, 2) + Math.pow(distanceInMetersY, 2));

    return latLngFromAngleLength(baseLatitude, baseLongitude, azi, distance);
}

function latLngFromAngleLength(baseLatitude, baseLongitude, angleDeg, length) {
    var geod = GeographicLib.Geodesic.WGS84;
    var azi = angleDeg;
    var distance = length;

    var r = geod.Direct(baseLatitude, baseLongitude, azi, distance);

    return [r.lat2, r.lon2];
}

function angleFromCoordinate(lat1, long1, lat2, long2) {
    // Código original: https://stackoverflow.com/a/18738281/
    var dLon = (long2 - long1);

    var y = Math.sin(dLon) * Math.cos(lat2);
    var x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);

    var brng = Math.atan2(y, x);

    brng = toDegrees(brng);
    brng = (brng + 360) % 360;
    brng = 360 - brng; // count degrees counter-clockwise - remove to make clockwise

    return brng;
}

function averageLatLng(coords) {
    // Código original: https://gist.github.com/tlhunter/0ea604b77775b3e7d7d25ea0f70a23eb
    if (coords.length === 0) {
        console.error("Can't find average for empty list of coordinates");
        return null;
    }
    else if (coords.length === 1) {
        return coords[0];
    }

    var x = 0.0;
    var y = 0.0;
    var z = 0.0;

    for (var i = 0; i < coords.length; i++) {
        var coord = coords[i];
        var latitude = coord.latitude * Math.PI / 180;
        var longitude = coord.longitude * Math.PI / 180;

        x += Math.cos(latitude) * Math.cos(longitude);
        y += Math.cos(latitude) * Math.sin(longitude);
        z += Math.sin(latitude);
    }

    var total = coords.length;

    x = x / total;
    y = y / total;
    z = z / total;

    var centralLongitude = Math.atan2(y, x);
    var centralSquareRoot = Math.sqrt(x * x + y * y);
    var centralLatitude = Math.atan2(z, centralSquareRoot);

    return {
        latitude: centralLatitude * 180 / Math.PI,
        longitude: centralLongitude * 180 / Math.PI
    };
}

function hasClassInHierarchy(htmlElement, className) {
    var el = htmlElement;
    while(el != null) {
        if (el.classList.contains(className)) {
            return true;
        }
        el = el.parentElement;
    }
    return false;
}

function propToHtml(owner, prop, socket) {
    if (prop.__class__ == "KeyValue") {
        var panelDataProp = prop;

        var panelDataPropEl = document.createElement("div");
        panelDataPropEl.className = "data-panel-prop";

        var propKeyEl = document.createElement("strong");
        propKeyEl.innerText = panelDataProp.key;

        var propValueEl = document.createElement("span");
        propValueEl.innerText = panelDataProp.value;

        panelDataPropEl.appendChild(propKeyEl);
        panelDataPropEl.appendChild(propValueEl);
        return panelDataPropEl;
    } else if (prop.__class__ == "Button") {
        var panelDataButton = prop;

        var panelDataButtonEl = document.createElement("div");
        panelDataButtonEl.className = "data-panel-button";

        var buttonEl = document.createElement("button");
        buttonEl.className = "data-panel-button";
        buttonEl.dataset.uid = panelDataButton.uid;
        buttonEl.innerText = panelDataButton.name;

        panelDataButtonEl.appendChild(buttonEl);
        return panelDataButtonEl;
    } else if (prop.__class__ == "Checkbox") {
        var panelDataCheckbox = prop;

        var panelDataCheckboxEl = document.createElement("div");
        panelDataCheckboxEl.className = "data-panel-checkbox-wrapper";

        var checkboxEl = document.createElement("input");
        checkboxEl.type = "checkbox";
        checkboxEl.dataset.uid = panelDataCheckbox.uid;
        checkboxEl.dataset.parent_uid = owner.uid;
        checkboxEl.className = "data-panel-checkbox";

        if (panelDataCheckbox.checked) {
            checkboxEl.checked = "checked";
        }

        panelDataCheckboxEl.appendChild(checkboxEl);
        panelDataCheckboxEl.appendChild(document.createTextNode(panelDataCheckbox.label));
        return panelDataCheckboxEl;
    } else if (prop.__class__ == "Textbox") {
        var panelDataTextbox = prop;

        var textboxEl = document.createElement("input");
        textboxEl.dataset.uid = panelDataTextbox.uid;
        textboxEl.dataset.parent_uid = owner.uid;
        textboxEl.className = "data-panel-textbox";
        textboxEl.defaultValue = panelDataTextbox.value;
        /*textboxEl.oninput = function(){
            console.log("validity empty");
            this.setCustomValidity('');
        };*/


        if (panelDataTextbox.disabled == true) {
            textboxEl.setAttribute("disabled", "");
        }

        if (panelDataTextbox.textbox_type == "text") {
            if (panelDataTextbox.pattern != null) {
                textboxEl.pattern = panelDataTextbox.pattern;
                console.log("1 text");

                textboxEl.oninvalid = function(){
                    console.log("invalid!");
                    this.setCustomValidity('Field requires a value that matches the regex pattern "' + panelDataTextbox.pattern + '"')
                };
            }
        } else if (panelDataTextbox.textbox_type == "number") {
            textboxEl.type = "number"
            var errorMessage = "Choose a number"
            if (panelDataTextbox.min != null) {
                textboxEl.min = panelDataTextbox.min;
                errorMessage += " greater than " + panelDataTextbox.min;
            }
            if (panelDataTextbox.max != null) {
                textboxEl.max = panelDataTextbox.max;
                errorMessage += " and smaller than " + panelDataTextbox.max;
            }
            textboxEl.step = "any";
            textboxEl.lang = "en-150";
            textboxEl.addEventListener("invalid", function(){
                this.setCustomValidity(errorMessage)
            });
        } else {
            console.error("Invalid textbox type " + panelDataTextbox.textbox_type);
        }

        return textboxEl;

    } else {
        console.error("Unknown type '" + panelData.__class__ + "' in propListToHtml");
        return null;
    }
}

function propListToHtml(owner, propList, socket) {
    var wrapEl = document.createElement("div");

    for (var i = 0; i < propList.length; i++) {
        wrapEl.appendChild(propToHtml(owner, propList[i], socket));
    }

    return wrapEl;
}