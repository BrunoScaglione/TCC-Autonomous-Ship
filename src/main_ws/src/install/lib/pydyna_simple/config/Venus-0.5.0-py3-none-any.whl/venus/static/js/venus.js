"use strict";

class Venus {

    constructor() {
        this.socket = new VenusSocket('ws://' + window.location.host + '/ws');

        this.socket.onConnectionSuccess = this.onConnectionSuccess.bind(this);

        this.socket.onViewportChange = (msg) => this.setViewport(msg.center, msg.zoom);
        this.socket.onViewportCenterChange = (msg) => this.setViewportCenter(msg.center);
        this.socket.onViewportZoomChange = (msg) => this.setViewportZoom(msg.zoom);

        this.socket.onObjectAdded = this.onObjectAdded.bind(this);
        this.socket.onObjectUpdated = this.onObjectUpdated.bind(this);
        this.socket.onDelete = this.onDelete.bind(this);
        this.socket.onObjectRemoved = this.onObjectRemoved.bind(this);

        this.mousePosition = {x: null, y: null, lat: null, lng: null};

        this.objectEventHandlers = Object.fromEntries([
            ["Vessel", new VesselEventHandler(this.socket, this.mousePosition)],
            ["Geotiff", new GeotiffEventHandler()],
            ["Line", new LineEventHandler(this.socket, this.mousePosition)],
            ["Beacon", new BeaconEventHandler(this.socket, this.mousePosition)],
            ["Panel", new PanelEventHandler(
                document.querySelector("#data-panel-holder"),
                this.socket
            )],
            ["Polygon", new PolygonEventHandler(this.socket, this.mousePosition)],
            ["Arrow", new ArrowEventHandler()],
        ]);

        this.objects = [];
        this.map = null;

        document.addEventListener("click", (evt) => {
            if (evt.target.classList.contains("data-panel-button")) {
                var uid = evt.target.dataset.uid;
                this.socket.send(JSON.stringify(
                    {
                        "__class__": "ButtonClicked",
                        "button_uid": uid,
                    }
                ));
            } else if (evt.target.classList.contains("data-panel-checkbox")) {
                var uid = evt.target.dataset.uid;
                var parent_uid = parseInt(evt.target.dataset.parent_uid);
                this.socket.send(JSON.stringify(
                    {
                        "__class__": "CheckboxChanged",
                        "checkbox_uid": uid,
                        "parent_uid": parent_uid,
                        "checked": evt.target.checked,
                    }
                ));
            }
        });

        function sendTextboxChanges(venus, evt) {
            if (evt.target.classList.contains("data-panel-textbox")) {
                var uid = evt.target.dataset.uid;
                var parent_uid = parseInt(evt.target.dataset.parent_uid);
                venus.socket.send(JSON.stringify(
                    {
                        "__class__": "TextboxChanged",
                        "textbox_uid": uid,
                        "parent_uid": parent_uid,
                        "value": evt.target.value,
                    }
                ));
            }
        }

        document.addEventListener("keyup", (evt) => {
            sendTextboxChanges(this, evt);
        });

        document.addEventListener("change", (evt) => {
            sendTextboxChanges(this, evt);
        });

        document.addEventListener("submit", (evt) => {
            sendTextboxChanges(this, evt);
        });

        document.addEventListener("mousemove", (evt) => {
            this.mousePosition.x = evt.clientX;
            this.mousePosition.y = evt.clientY;

            if (this.map != null) {
                var latlng = this.map.mouseEventToLatLng(evt);
                this.mousePosition.lat = latlng.lat;
                this.mousePosition.lng = latlng.lng;
            } else {
                this.mousePosition.lat = null;
                this.mousePosition.lng = null;
            }
        });
    }

    createMap(key) {
        var config = {
            center: [-22.983334, -43.159303],
            layers: L.mapquest.tileLayer('map'),
            zoom: 10,
            editable: true,
            doubleClickZoom: false,
            closePopupOnClick: false,
            //zoomAnimation: false,
        };

        L.mapquest.key = key;
        var map = L.mapquest.map('map', config);

        map.on("click", (evt) => {
            this.socket.send(JSON.stringify(
                {
                    "__class__": "MapClicked",
                    "latitude": evt.latlng.lat,
                    "longitude": evt.latlng.lng,
                }
            ));
        });

        return map;
    }

    setViewport(center, zoom) {
        this.map.setView([center.latitude, center.longitude], zoom);
    }

    setViewportCenter(center) {
        this.map.panTo([center.latitude, center.longitude]);
    }

    setViewportZoom(zoom) {
        this.map.setZoom(zoom);
    }

    onConnectionSuccess(msg) {
        if (this.map != undefined) {
            this.map.remove();
        }

        if (msg.mapquest_key == null) { msg.mapquest_key = "no_key_at_all"; }

        try {
            this.map = this.createMap(msg.mapquest_key);
        } catch (e) {
            console.error(e);
        }

        this.objects = [];
        document.querySelector("#data-panel-holder").innerHTML = "";

        if (msg.viewport_center != null && msg.viewport_zoom != null) {
            this.setViewport(msg.viewport_center, msg.viewport_zoom);
        } else {
            if (msg.viewport_center != null) {
                this.setViewportCenter(msg.viewport_center);
            }
            if (msg.viewport_zoom != null) {
                this.setViewportZoom(msg.viewport_zoom);
            }
        }
        for (var i = 0; i < msg.objects.length; i++) {
            this.onObjectAdded(msg.objects[i]);
        }
    }

    onObjectAdded(object) {
        if (object.__class__ in this.objectEventHandlers) {
            this.objectEventHandlers[object.__class__].add(object, this.map, this.objects);
        } else {
            throw new Error("Invalid object received: " + object.constructor.name + " | " + JSON.stringify(object));
        }
    }

    onObjectUpdated(updateInfo) {
        if (updateInfo.ctx != null && updateInfo.ctx.length > 0 && updateInfo.ctx[0].uid != null) {
            var foundObject = this.objects.find((o) => o.obj.uid == updateInfo.ctx[0].uid);
            if (foundObject == null) {
                throw new Error("Update event could not find object with ID " + updateInfo.ctx[0].uid);
            }

            if (foundObject.obj.__class__ in this.objectEventHandlers) {
                this.objectEventHandlers[foundObject.obj.__class__].update(foundObject, updateInfo, this.map, this.objects);
            } else {
                throw new Error("Invalid object received for updating: " + foundObject.obj.__class__);
            }
        } else {
            throw new Error("Update event context has to start with an ID " + JSON.stringify(updateInfo));
        }
    }

    onDelete(deleteInfo) {
        if (deleteInfo.ctx != null && deleteInfo.ctx.length > 0 && deleteInfo.ctx[0].uid != null) {
            var foundObject = this.objects.find((o) => o.obj.uid == deleteInfo.ctx[0].uid);
            if (foundObject == null) {
                throw new Error("Delete event could not find object with ID " + deleteInfo.ctx[0].uid);
            }

            if (foundObject.obj.__class__ in this.objectEventHandlers) {
                this.objectEventHandlers[foundObject.obj.__class__].delete_(foundObject, deleteInfo, this.map, this.objects);
            } else {
                throw new Error("Invalid object received for deleting: " + foundObject.obj.__class__);
            }
        } else {
            throw new Error("Delete event context has to start with an ID " + JSON.stringify(deleteInfo));
        }
    }

    onObjectRemoved(removed) {
        if (removed.uid != null) {
            var foundObject = this.objects.find((o) => o.obj.uid == removed.uid);
            if (foundObject == null) {
                throw new Error("Remove event could not find object with ID " + removed.uid);
            }

            if (foundObject.obj.__class__ in this.objectEventHandlers) {
                this.objects = this.objects.filter(o => o != foundObject);
                this.objectEventHandlers[foundObject.obj.__class__].remove(foundObject, this.map, this.objects);
            } else {
                throw new Error("Invalid object received for deleting: " + foundObject.obj.__class__);
            }
        } else {
            throw new Error("Remove message without an object ID");
        }
    }
}