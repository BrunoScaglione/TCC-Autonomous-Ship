"use strict";

function createStyle(className, classDefinition) {
    var style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = '.' + className + ' { \n';
    for (var key in classDefinition) {
        style.innerHTML += key + ": " + classDefinition[key] + ";\n";
    }
    style.innerHTML += "}\n";
    document.getElementsByTagName('head')[0].appendChild(style);

    return document.styleSheets[document.styleSheets.length-1];
}

class BeaconVisual {
    constructor(marker, styleSheet, tooltipElement) {
        this.marker = marker;
        this.styleSheet = styleSheet;
        this.tooltipElement = tooltipElement;
    }
}

class BeaconEventHandler extends VenusObjectEventHandler {
    constructor(socket, mousePosition) {
        super();
        this._socket = socket;
        this._mousePosition = mousePosition;
    }

    add(beacon, map, objects) {

        var baseBeaconCss = {
            /*"width": "40px",
            "height": "40px",
            "border-radius": "10px",
            "border": "1px solid black",
            "box-sizing": "border-box",
            "background-color": "white",*/
        };

        for (var opt in beacon.visual_options) {
            baseBeaconCss[opt] = beacon.visual_options[opt];
        }

        var className = "beacon-" + beacon.uid;
        var styleSheet = createStyle(className, baseBeaconCss);

        var beaconIcon;
        if (Object.keys(baseBeaconCss).length > 0) {
            beaconIcon = L.divIcon({"className": className});
        } else {
            beaconIcon = L.divIcon({"className": "beacon-base"});
        }
        var marker = L.marker(
            [beacon.position.latitude, beacon.position.longitude],
            {icon: beaconIcon, draggable: beacon.draggable}
        ).addTo(map);
        marker._venus_uid = beacon.uid;

        if (beacon.data_panel.length > 0) {
            var tooltipContent = propListToHtml(beacon, beacon.data_panel, this._socket);
            marker.bindTooltip(tooltipContent, {
                permanent: true,
                direction: "top",
                interactive: true,
                opacity: 1,
                offset: [0, -20],
                closeOnClick: false,
            });

            marker.closeTooltip();
        }

        marker.on('click', (evt) => {
            if (!hasClassInHierarchy(evt.originalEvent.target, "leaflet-tooltip")) {
                marker.toggleTooltip();
            }
        });

        marker.on('dragstart', (evt) => {
            var obj = objects.find((o) => o.obj.uid == evt.target._venus_uid);
            this._socket.send(JSON.stringify(
                {
                    "__class__": "ObjectDragStart",
                    "object_uid": obj.obj.uid,
                }
            ));
        });

        marker.on('dragend', (evt) => {
            var obj = objects.find((o) => o.obj.uid == evt.target._venus_uid);
            this._socket.send(JSON.stringify(
                {
                    "__class__": "ObjectDragEnd",
                    "object_uid": obj.obj.uid,
                    "new_position": {"latitude": this._mousePosition.lat, "longitude": this._mousePosition.lng},
                }
            ));
        });

        objects.push(new VenusObject(beacon, [marker, styleSheet]));

        window.beacon = [beacon, marker, styleSheet];
    }

    update(oldObj, updateInfo, map, objects) {
        if (updateInfo.ctx.length == 2) {
            if (updateInfo.ctx[1].prop == "position") {
                oldObj.visual[0].setLatLng([updateInfo.value.latitude, updateInfo.value.longitude]);
                oldObj.obj.position = updateInfo.value;
            }
            else if (updateInfo.ctx[1].prop == "data_panel") {
                var tooltipContent = propListToHtml(oldObj.obj, updateInfo.value, this._socket);
                oldObj.visual[0].setTooltipContent(tooltipContent);
                oldObj.visual[0].getTooltip().setLatLng([oldObj.obj.position.latitude, oldObj.obj.position.longitude]);
                oldObj.obj.data_panel = updateInfo.value;
            }
            else if (updateInfo.ctx[1].prop == "visual_options") {
                oldObj.visual[1].deleteRule(0);
                oldObj.visual[1].insertRule(".beacon-" + oldObj.obj.uid + " {" + Object.keys(updateInfo.value).map( k => k + ": " + updateInfo.value[k] + ";" ).join("") + "}");
                if (Object.keys(updateInfo.value).length > 0) {
                    if (oldObj.visual[0].getElement().classList.contains("beacon-base")) {
                        oldObj.visual[0].getElement().classList.remove("beacon-base");
                        oldObj.visual[0].getElement().classList.add("beacon-" + oldObj.obj.uid);
                    }
                } else {
                    if (oldObj.visual[0].getElement().classList.contains("beacon-" + oldObj.obj.uid)) {
                        oldObj.visual[0].getElement().classList.remove("beacon-" + oldObj.obj.uid);
                        oldObj.visual[0].getElement().classList.add("beacon-base");
                    }
                }

                oldObj.obj.visual_options = updateInfo.value;
            }
            else if (updateInfo.ctx[1].prop == "draggable") {
                if (updateInfo.value) {
                    oldObj.visual[0].dragging.enable();
                } else {
                    oldObj.visual[0].dragging.disable();
                }
                oldObj.obj.draggable = updateInfo.value;
            }
            else {
                console.error("invalid property to update on beacon", updateInfo);
            }
        }
        else if (updateInfo.ctx.length == 3) {
            if (updateInfo.ctx[1].prop == "position") {
                if (updateInfo.ctx[2].prop == "latitude") {
                    oldObj.visual[0].setLatLng([updateInfo.value, oldObj.obj.position.longitude]);
                    oldObj.obj.position.latitude = updateInfo.value;
                }
                else if (updateInfo.ctx[2].prop == "longitude") {
                    oldObj.visual[0].setLatLng([oldObj.obj.position.latitude, updateInfo.value]);
                    oldObj.obj.position.longitude = updateInfo.value;
                }
                else {
                    console.error("invalid property to update on beacon", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "visual_options") {
                if (updateInfo.ctx[2].prop != null) {
                    oldObj.obj.visual_options[updateInfo.ctx[2].prop] = updateInfo.value;
                    oldObj.visual[1].rules[0].style[updateInfo.ctx[2].prop] = updateInfo.value;

                    if (oldObj.visual[0].getElement().classList.contains("beacon-base")) {
                        oldObj.visual[0].getElement().classList.remove("beacon-base");
                        oldObj.visual[0].getElement().classList.add("beacon-" + oldObj.obj.uid);
                    }
                }
                else {
                    console.error("invalid property to update on beacon", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "data_panel") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;
                    if (oldObj.visual[0].getTooltip() == null) {
                        var newPropHtml = propListToHtml(oldObj.obj, [updateInfo.value], this._socket);
                        oldObj.visual[0].bindTooltip(newPropHtml, {
                            permanent: true,
                            direction: "top",
                            interactive: true,
                            opacity: 1,
                            offset: [0, -20],
                            closeOnClick: false,
                        });

                        oldObj.visual[0].closeTooltip();
                    } else {
                        var newPropHtml = propToHtml(oldObj, updateInfo.value, this._socket);
                        if (i < oldObj.visual[0].getTooltip().getContent().children.length) {
                            oldObj.visual[0].getTooltip().getContent().children[i].outerHTML = newPropHtml.outerHTML;
                        }
                        else {
                            oldObj.visual[0].getTooltip().getContent().appendChild(newPropHtml);
                            oldObj.visual[0].getTooltip().setLatLng([oldObj.obj.position.latitude, oldObj.obj.position.longitude]);
                        }
                    }
                    oldObj.obj.data_panel[i] = updateInfo.value;
                }
                else {
                    console.error("invalid property to update on beacon", updateInfo);
                }
            }
            else {
                console.error("invalid property to update on beacon", updateInfo);
            }
        }
        else if (updateInfo.ctx.length == 4) {
            if (updateInfo.ctx[1].prop == "data_panel") {
                updateDataPanelObject(updateInfo, oldObj, true);
            }
            else {
                console.error("invalid property to update on vessel", updateInfo);
            }
        }
        else {
            console.error("invalid property to update on beacon", updateInfo);
        }
    }

    delete_(oldObj, updateInfo, map, objects) {
        if (updateInfo.ctx.length == 3) {
            if (updateInfo.ctx[1].prop == "visual_options") {
                if (updateInfo.ctx[2].prop != null) {
                    var propToDelete = updateInfo.ctx[2].prop;
                    delete oldObj.obj.visual_options[propToDelete];
                    delete oldObj.visual[1].rules[0].style.removeProperty(propToDelete);
                    if (Object.keys(oldObj.obj.visual_options).length == 0) {
                        if (oldObj.visual[0].getElement().classList.contains("beacon-" + oldObj.obj.uid)) {
                            oldObj.visual[0].getElement().classList.remove("beacon-" + oldObj.obj.uid);
                            oldObj.visual[0].getElement().classList.add("beacon-base");
                        }
                    }
                    //console.log(oldObj.visual[1].rules[0].style);
                } else {
                    console.error("invalid property to delete on polygon", updateInfo);
                }
            }
            else if (updateInfo.ctx[1].prop == "data_panel") {
                if (updateInfo.ctx[2].i != null) {
                    var i = updateInfo.ctx[2].i;
                    oldObj.visual[0].getTooltip().getContent().children[i].remove();
                    oldObj.obj.data_panel.splice(i, 1);
                    if (oldObj.obj.data_panel.length == 0) {
                        oldObj.visual[0].unbindTooltip();
                    } else {
                        oldObj.visual[0].getTooltip().setLatLng([oldObj.obj.position.latitude, oldObj.obj.position.longitude]);
                    }
                } else {
                    console.error("invalid property to delete on polygon", updateInfo);
                }
            }
            else {
                console.error("invalid property to delete on polygon", updateInfo);
            }
        }
        else {
            console.error("invalid property to delete on polygon", updateInfo);
        }
    }

    remove(beacon, map, objects) {
        beacon.visual[0].removeFrom(map);
    }
}
