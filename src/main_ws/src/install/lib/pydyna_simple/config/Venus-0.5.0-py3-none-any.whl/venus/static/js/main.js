"use strict";

var v = new Venus();