from venus.viewer import Venus
from venus.objects import (
    Vessel,
    GeoPos,
    Rudder,
    Size,
    KeyValue,
    Button,
    Line,
    Panel,
    Polygon,
    Beacon,
    Arrow,
    Checkbox,
    Textbox,
    TextboxType,
)
from math import sin, cos, pi, radians
from time import sleep
from datetime import datetime


def main():
    # We define a central position.
    central_position = GeoPos(-23.06255, -44.2772)

    # Create a new Venus instance and change the viewport to look at our central_position.
    venus = Venus(logging=True, port=6150)

    # We need to make sure we call `venus.stop()` after we are done, so we are going to run this code inside
    # a try block and call `stop` in the `finally` block.
    try:
        venus.set_viewport(central_position, 15)

        # Creating a Polygon
        polygon1 = venus.add(
            Polygon(
                # These points define a 32-sided polygon
                points=[
                    central_position.relative(sin(radians(n)) * 400, cos(radians(n)) * 400)
                    for n in range(0, 360, int(360 / 32))
                ],

                # Visual options for the polygon
                visual_options={"color": "yellow", "fillOpacity": 0.1, "weight": 3},

                # Some test properties on the data panel
                data_panel=[
                    KeyValue("Poly", "Gone"),
                    Button("btn_poly", "Poly"),
                    Checkbox("chk_polygon1", "Check Poly", False),
                ],

                # This polygon can be dragged by the user
                draggable=True,
            )
        )

        # Creating a Vessel
        vessel1 = venus.add(
            Vessel(
                position=central_position,

                # angle = 0 means the vessel is pointing north
                angle=0,

                # The vessel has a width of 40 meters and a height of 200 meters in the 2D plane.
                size=Size(40, 200),

                # A rudder with angle = 0 means the rudder is pointing south. A length = 0.1 means 10% of the vessel
                # height, so our rudder has 20 meters.
                rudders=[Rudder(angle=0, length=0.1, visual_options={"color": "red"})],

                # All possible visual options
                visual_options={
                    "stroke": True,
                    "color": "#3388ff",  # stroke color
                    "weight": 3,  # stroke weight
                    "opacity": 1.0,  # stroke opacity
                    "lineCap": "round",
                    "lineJoin": "round",
                    "dashArray": None,
                    "dashOffset": None,
                    "fill": True,
                    "fillColor": "#3388ff",
                    "fillOpacity": 0.2,
                    "fillRule": "evenodd",
                },

                # More data panel test properties
                data_panel=[
                    KeyValue("ID", "0"),
                    KeyValue("Width", "40"),
                    KeyValue("Height", "200"),
                    Button("btn_vessel", "Click here"),
                ],

                draggable=True,

                # User can rotate this vessel
                can_rotate=True,
            )
        )

        def rotate_end(obj, angle):
            obj.angle = angle

        venus.on_object_rotate_end = rotate_end

        # Creating a Line
        line1 = venus.add(
            Line(
                # Here the points are relative to the central_position we defined earlier. The first point is
                # 300 meters away from the central point in both x and y axis.
                points=[central_position.relative(-300, -300), central_position.relative(300, -300)],

                visual_options={"color": "yellow", "weight": 10},
                data_panel=[KeyValue("Line", "---"), Button("btn_line", "Click here")],
                draggable=True,
            )
        )

        sleep(2)

        # Creating a Panel
        panel1 = venus.add(
            Panel(
                data_panel=[
                    Checkbox("chk_drag_elements", "Drag elements", True),
                    Checkbox("chk_add_beacons", "Add beacons", False),
                    # A simple textbox, see the docs for more
                    Textbox("txt_panel1", "", disabled=True),
                    Textbox("txt_panel2", 0, textbox_type=TextboxType.NUMBER, min=0, max=0.5),
                    Textbox("txt_panel2", 0, textbox_type=TextboxType.NUMBER, min=0, max=10),
                ]
            )
        )

        # Now we are going to create two beacons. We want one 500 meters to the right of the central
        # point and one 500 meters to the left. Both beacons are also going to orbit around their
        # positions, the one on the right can be dragged by the user to change its orbiting position,
        # (that's why we have the beacon0_central_position variable) and the one on the left is fixed.

        beacon0_central_position = central_position.relative(500, 0)
        beacons = [
            venus.add(
                Beacon(
                    position=beacon0_central_position,
                    visual_options={"background-color": "red"},

                    # Emojis are also supported
                    data_panel=[KeyValue("Whale", "🐳")],

                    draggable=True,
                )
            ),
            venus.add(
                Beacon(
                    position=central_position.relative(-500, 0),
                    visual_options={},
                    data_panel=[KeyValue("Lion", "🦁")],
                )
            ),
        ]

        # Creating an arrow
        arrow1 = venus.add(
            Arrow(
                position=central_position.relative(0, -400),
                angle=0,

                # Length in meters
                length=200,

                visual_options={"color": "green"},
            )
        )

        # If the user selects a checkbox we flip this and interpret clicks to add beacons
        add_beacons_mode = False

        # Callback for buttons
        def on_button_clicked(button_uid):
            print(f"Button clicked: {button_uid}")

        # Callback for checkboxes
        def on_checkbox_changed(checkbox_uid, checked):
            nonlocal add_beacons_mode

            # You can enable and disable dragging dynamically
            if checkbox_uid == "chk_drag_elements":
                vessel1.draggable = checked
                vessel1.can_rotate = checked
                beacons[0].draggable = checked
                line1.draggable = checked
                polygon1.draggable = checked

            # Change the add_beacons_mode
            elif checkbox_uid == "chk_add_beacons":
                add_beacons_mode = checked

        # Callback for when the user releases the dragged object
        # (on_object_drag_start can also be defined despite being ommited from this example)
        def on_object_drag_end(obj, new_position):
            nonlocal beacon0_central_position

            # If we got a vessel or the first beacon we simply update their position. The rest
            # of the objects are ignored. Ignored objects might snap back to their original positions
            # or not depending on some factors. An advice is to always explicitly set the object's
            # position when it stops being dragged.
            if obj == vessel1:
                obj.position = new_position
            elif obj == beacons[0]:
                beacon0_central_position = new_position

        # Callback called when the user clicks the map. This is only called when the actual map is clicked
        # and not any of the other elements.
        def on_map_clicked(pos):
            nonlocal add_beacons_mode

            # If the user checks the checkbox, we interpret clicking as adding beacons.
            if add_beacons_mode:
                beacons.append(venus.add(Beacon(
                    position=pos,
                    data_panel=[KeyValue("Dynamic beacon", "!!!")],
                )))

        # Finally setup all callbacks
        venus.on_button_clicked = on_button_clicked
        venus.on_checkbox_changed = on_checkbox_changed
        venus.on_object_drag_end = on_object_drag_end
        venus.on_map_clicked = on_map_clicked

        counter = 0.0
        while True:
            # Setting a value for a textbox
            panel1.data_panel[2].value = str(counter)

            # Our arrow orbits around a circle and changes angle and length based on this angle.
            new_arrow_pos = central_position.relative(sin(counter) * 400, cos(counter) * 400)
            arrow1.position = new_arrow_pos
            arrow1.angle = counter * 180 / pi + 90
            arrow1.length = sin(counter) * 200

            if not beacons[0].is_being_dragged():
                # Here we ignore the central position defined earlier and use beacon0_central_position
                # as the absolute value.
                beacons[0].position = beacon0_central_position.relative(
                    sin(counter * 5) * 100, cos(counter * 5) * 100
                )

            beacons[1].position = central_position.relative(-500, 0).relative(
                sin(-counter * 5) * 100, cos(-counter * 5) * 100
            )

            counter += 0.01

            # It is recommended to sleep for some time to avoid flooding the browser with messages, but
            # you can get away with not sleeping depending on the complexity of what you are doing.
            sleep(0.05)
    except KeyboardInterrupt:
        pass
    finally:
        venus.stop()


if __name__ == "__main__":
    main()
