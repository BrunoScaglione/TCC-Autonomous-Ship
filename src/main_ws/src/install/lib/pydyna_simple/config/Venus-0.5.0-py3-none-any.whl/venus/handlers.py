from abc import ABC, abstractmethod
from tornado.websocket import WebSocketHandler


class WebSocketEventHandler(ABC):
    @abstractmethod
    def on_ws_open(self, socket: WebSocketHandler):
        pass

    @abstractmethod
    def on_ws_message(self, socket: WebSocketHandler, message):
        pass

    @abstractmethod
    def on_ws_close(self, socket: WebSocketHandler):
        pass
