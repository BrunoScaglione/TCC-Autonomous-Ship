"use strict";

class VenusObject {
    constructor(obj, visual) {
        this.obj = obj;
        this.visual = visual;
    }
}

class VenusObjectEventHandler {
    constructor() {
        if (this.constructor === VenusObjectEventHandler) {
            throw new TypeError('Abstract class "VenusObjectEventHandler" cannot be instantiated directly.'); 
        }
    }

    add(obj, map, objects) {
        throw new TypeError('Method "add" not implemented for ' + typeof(this));
    }

    update(oldObj, updateInfo, map, objects) {
        throw new TypeError('Method "update" not implemented for ' + typeof(this));
    }

    remove(obj, map, objects) {
        throw new TypeError('Method "remove" not implemented for ' + typeof(this));
    }

    delete_(oldObj, updateInfo, map, objects) {
        throw new TypeError('Method "delete_" not implemented for ' + typeof(this));
    }
}