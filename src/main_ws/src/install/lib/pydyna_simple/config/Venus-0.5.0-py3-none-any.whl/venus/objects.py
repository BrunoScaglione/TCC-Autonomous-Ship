from venus.network import NetworkObject
from typing import Union, List, Dict, Optional
from copy import deepcopy
from pathlib import Path
from math import atan2, sqrt, pow, pi
from geographiclib.geodesic import Geodesic, Constants
#from enum import Enum
import gdal
import hashlib
import os
import enum


class KeyValue:
    """
    Represents a key-value pair. Must be inserted into a #DataPanel and shows up in the interface as "**Key**: Value".

    - `key`: The "title" of the property.
    - `value`: The value of the property.
    """
    def __init__(self, key: str, value: str):
        self.key = key
        self.value = value

    def __ne__(self, other):
        if isinstance(other, KeyValue):
            return self.key != other.key or self.value != other.value
        else:
            return True

    def __eq__(self, other):
        return not (self != other)


class Button:
    """
    A button that can be added to any #DataPanel.

    - `uid`: An unique identifier for the button. Event callbacks receive this value so you can identify
    which element was interacted with.
    - `name`: The name of the button.
    """
    def __init__(self, uid: str, name: str):
        self.uid = uid
        self.name = name

    def __ne__(self, other):
        if isinstance(other, Button):
            return self.uid != other.uid or self.name != other.name
        else:
            return True

    def __eq__(self, other):
        return not (self != other)


class Checkbox:
    """
    A checkbox that can be added to any #DataPanel.

    - `uid`: A unique identifier for the checkbox. Event callbacks receive this value so you can identify
    which element was interacted with.
    - `label`: A text that shows up beside the checkbox.
    - `checked`: The starting state of the checkbox.
    """
    def __init__(self, uid: str, label: str, checked: bool):
        self.uid = uid
        self.label = label
        self.checked = checked

    def __ne__(self, other):
        if isinstance(other, Checkbox):
            return self.uid != other.uid or self.label != other.label or self.checked != other.checked
        else:
            return True

    def __eq__(self, other):
        return not (self != other)


class TextboxType(enum.Enum):
    """
    An enumeration used by #Textbox.

    - `TextboxType.TEXT`: Represents a text field and allows you to set a regex pattern of valid strings.
    - `TextboxType.NUMBER`: Represents a number field and allows you to set a minimum and a maximum value.
    """
    TEXT = "text"
    NUMBER = "number"


class Textbox:
    """
    A textbox that can be added to any #DataPanel. While other properties can be updated and have their values
    reflected on the browser, `textbox_type` can only be set during the creation of the textbox. If you need to
    change the type of a textbox destroy it and create another in the same place.

    - `uid`: A unique identifier for the textbox. Event callbacks receive this value so you can identify
    which element was interacted with.
    - `value`: A text that shows up inside the textbox.
    - `disabled`: Whether the user can edit the contents or not.
    - `textbox_type`: Used for error handling. By choosing either `TextboxType.TEXT` or
    `TextboxType.NUMBER` invalid values will be highlighted in red. You can pick which values are valid for a text
    field by using the extra `pattern` parameter which is a regex pattern. You can pick which values are valid for a
    number field by using the extra parameters `min` and `max`. Invalid values are still sent to the server through
    the `on_textbox_changed` callback so you should still do your own validation.

    ### Example
    ```python
    Textbox("txt_radius", "100", textbox_type=TextboxType.NUMBER, min=0, max=1000)
    Textbox("txt_radius", "100", textbox_type=TextboxType.TEXT, pattern=r"^[-+]?\\d+$")
    ```
    """

    def __init__(self, uid: str, value: Union[str, int, float] = "", disabled: bool = False, textbox_type: TextboxType = TextboxType.TEXT, **kwargs):
        self.uid = uid
        self.value = value
        self.textbox_type = textbox_type.value
        self.disabled = disabled

        if self.textbox_type == TextboxType.TEXT.value:
            self.pattern = None if "pattern" not in kwargs else kwargs["pattern"]
        elif self.textbox_type == TextboxType.NUMBER.value:
            self.min = None if "min" not in kwargs else kwargs["min"]
            self.max = None if "max" not in kwargs else kwargs["max"]
        else:
            raise RuntimeError()

    def __ne__(self, other):
        if isinstance(other, Textbox):
            return self.uid != other.uid or self.value != other.value
        else:
            return True

    def __eq__(self, other):
        return not (self != other)


DataPanel = List[Union[KeyValue, Button, Checkbox, Textbox]]
VisualOptions = Dict[str, Union[int, float, str, bool, None]]


class GeoPos:
    """
    A class to define georeferenced positions.

    - `latitude`: Latitude of the position.
    - `longitude`: Longitude of the position.
    - `altitude`: An optional parameter for the altitude. It's not used anywhere by Venus but might have meaning in
    the future.

    ### Methods

    - `relative(meters_distance_x: float, meters_distance_y: float) -> GeoPos`: Returns a new `GeoPos` x and y meters
    distant from `self.latitude` and `self.longitude`.
    """
    _geodesic = Geodesic(Constants.WGS84_a, Constants.WGS84_f)

    def __init__(
        self, latitude: float, longitude: float, altitude: Union[float, None] = None
    ):
        self.latitude = latitude
        self.longitude = longitude
        self.altitude = altitude

    def relative(self, meters_distance_x: float, meters_distance_y: float) -> "GeoPos":
        azimuth = atan2(meters_distance_x, meters_distance_y) * 180 / pi
        distance = sqrt(pow(meters_distance_x, 2) + pow(meters_distance_y, 2))

        geo_result = GeoPos._geodesic.Direct(
            self.latitude, self.longitude, azimuth, distance
        )

        return GeoPos(geo_result["lat2"], geo_result["lon2"])

    def __ne__(self, other):
        if isinstance(other, GeoPos):
            return (
                self.latitude != other.latitude
                or self.longitude != other.longitude
                or self.latitude != other.latitude
            )
        else:
            return True

    def __eq__(self, other):
        return not (self != other)


class Size:
    """
    Represents a size in meters. Used to define #Vessel sizes. Width and height are used in the 2D sense, so height
    here means the size of meters in the 2D Y-axis.

    - `width`: Width in meters.
    - `height`: Height in meters.
    """
    def __init__(self, width: float, height: float):
        self.width = width
        self.height = height

    def __ne__(self, other):
        if isinstance(other, Size):
            return self.width != other.width or self.height != other.height
        else:
            return True

    def __eq__(self, other):
        return not (self != other)


class Bounds:
    """
    Represents a rectangular geographical area on a map.
    `min` and `max` should be two diagonally opposite corners of the rectangle you're defining.
    """
    def __init__(self, min: GeoPos, max: GeoPos):
        self.min = deepcopy(min)
        self.max = deepcopy(max)

    def __ne__(self, other):
        if isinstance(other, Bounds):
            return self.min != other.min or self.max != other.max
        else:
            return True

    def __eq__(self, other):
        return not (self != other)


class Beacon(NetworkObject):
    """
    A class used to draw #Beacons on the map.

    - `position`: The georeferenced position of the beacon.
    - `data_panel`: A panel that can be customized. Is accessed by clicking on the beacon. More information on
    the #Panel documentation.
    - `visual_options`: Graphical options for the beacon. Accepts any CSS property.
    - `draggable`: Enable or disable dragging for this element.

    #### Example:
    ```python
    Beacon(
        position=GeoPos(23, 45),
        visual_options={"background-color": "red"},
        data_panel=[KeyValue("Test", "42")],
        draggable=True,
    )
    ```

    ### Methods

    - `is_being_dragged`: Returns `True` if this element is being dragged on the frontend.
    """
    def __init__(
        self,
        position: GeoPos,
        data_panel: DataPanel = [],
        visual_options: VisualOptions = {},
        draggable=False,
    ):
        super().__init__()
        self.position = deepcopy(position)
        self.data_panel = deepcopy(data_panel)
        self.visual_options = deepcopy(visual_options)
        self.draggable = draggable
        self._dragging = False  # type: bool

    def is_being_dragged(self):
        return self._dragging

    def set_dragging(self, value: bool):
        """
        Cuidado: Esse método não deve ser chamado pelos clientes da API, ele existe apenas
        para manter a propriedade `_dragging` sincronizada com o navegador.
        """
        self._dragging = value


class Rudder:
    """
    A class used to add #Rudders to a #Vessel.

    - `angle`: The angle of the #Rudder in degrees. 0 is south, 90 is west.
    - `length`: Size of the #Rudder relative to the #Vessel it is attached. A value of 0.5 attached to a #Vessel
    with a height of 40 meters means a rudder with 20 meters length.
    - `visual_options`: Graphical options for the #Rudder. Check the #Polygon documentation for possible values.

    #### Example:
    See the #Vessel examples.
    """
    def __init__(
        self, angle: float, length: float = 0.1, visual_options: VisualOptions = {}
    ):
        self.angle = angle
        self.length = length
        self.visual_options = deepcopy(visual_options)


class Arrow(NetworkObject):
    """
    A class used to draw arrows on the map.

    - `position`: The position of arrow.
    - `angle`: The angle of the #Arrow in degrees. 0 is north, 90 is east.
    - `length`: Size of the arrow in meters.
    - `visual_options`: Graphical options for the #Arrow. Check the #Polygon documentation for possible values.

    #### Example:
    ```python
    Arrow(
        position=GeoPos(25, 43),
        angle=0,
        length=200,
        visual_options={"color": "green"},
    )
    ```
    """
    def __init__(
        self,
        position: GeoPos,
        angle: float,
        length: float,
        visual_options: VisualOptions = {},
    ):
        super().__init__()
        self.position = deepcopy(position)
        self.angle = angle
        self.length = length
        self.visual_options = deepcopy(visual_options)


class Vessel(NetworkObject):
    """
    A class used to add #Vessels to the map.

    - `position`: The georeferenced position of the vessel.
    - `angle`: Angle of the vessel in degrees. 0 is north, 90 is east.
    - `size`: #Size of the vessel in meters.
    - `rudders`: A list of #Rudders.
    - `data_panel`: A panel that can be customized. Is accessed by clicking on the vessel. More information on
    the #Panel documentation.
    - `visual_options`: Graphical options for the vessel. Check the #Polygon documentation for possible values.
    - `draggable`: Enable or disable dragging for this element.
    - `can_rotate`: Enable or disable user rotation of this vessel.

    #### Example:
    ```python
    vessel = venus.add(
        Vessel(
            position=GeoPos(-23.06255, -44.2772),
            angle=0,
            size=Size(40, 200),
            rudders=[Rudder(angle=0, length=0.1, visual_options={"color": "red"})],
            data_panel=[
                KeyValue("Vessel ID", "42"),
            ],
            visual_options={
                "stroke": False,
                "fillColor": "green",
            },
            draggable=True,
        )
    )

    while True:
        if not vessel.is_being_dragged():
            vessel.position.latitude += 0.1;
        sleep(0.1)
    ```

    ### Methods

    - `is_being_dragged`: Returns `True` if this element is being dragged on the frontend.
    - `is_being_rotated`: Returns `True` if this element is being rotated on the frontend.
    """
    def __init__(
        self,
        position: GeoPos,
        angle: float,
        size: Size,
        rudders: List[Rudder] = [],
        data_panel: DataPanel = [],
        visual_options: VisualOptions = {},
        draggable: bool = False,
        can_rotate: bool = False,
    ):
        super().__init__()
        self.position = deepcopy(position)
        self.angle = angle
        self.size = deepcopy(size)
        self.rudders = deepcopy(rudders)
        self.data_panel = deepcopy(data_panel)
        self.visual_options = deepcopy(visual_options)
        self.draggable = draggable
        self.can_rotate = can_rotate
        self._dragging = False  # type: bool
        self._rotating = False  # type: bool

    def is_being_dragged(self):
        return self._dragging

    def is_being_rotated(self):
        return self._rotating

    def set_dragging(self, value: bool):
        """
        Cuidado: Esse método não deve ser chamado pelos clientes da API, ele existe apenas
        para manter a propriedade `_dragging` sincronizada com o navegador.
        """
        self._dragging = value

    def set_rotating(self, value: bool):
        """
        Cuidado: Esse método não deve ser chamado pelos clientes da API, ele existe apenas
        para manter a propriedade `_rotating` sincronizada com o navegador.
        """
        self._rotating = value


class Line(NetworkObject):
    """
    A class used to add #Lines to the map.

    - `points`: A #Line can be defined by several points which are all connected.
    - `data_panel`: A panel that can be customized. Is accessed by clicking on the line. More information on
    the #Panel documentation.
    - `visual_options`: Graphical options for the line. Check the #Polygon documentation for possible values.
    - `draggable`: Enable or disable dragging for this element.

    #### Example:
    ```python
    Line(
        points=[GeoPos(23, 45), GeoPos(23, 45)],
        visual_options={"color": "yellow", "weight": 10},
        data_panel=[KeyValue("Line ID", "15"), Button("btn_line", "Click here!")],
        draggable=False,
    )
    ```

    ### Methods

    - `is_being_dragged`: Returns `True` if this element is being dragged on the frontend.
    """
    def __init__(
        self,
        points: List[GeoPos],
        data_panel: DataPanel = [],
        visual_options: VisualOptions = {},
        draggable=False,
    ):
        super().__init__()
        self.points = deepcopy(points)
        self.data_panel = deepcopy(data_panel)
        self.visual_options = deepcopy(visual_options)
        self.draggable = draggable
        self._dragging = False  # type: bool

    def is_being_dragged(self):
        return self._dragging

    def set_dragging(self, value: bool):
        """
        Cuidado: Esse método não deve ser chamado pelos clientes da API, ele existe apenas
        para manter a propriedade `_dragging` sincronizada com o navegador.
        """
        self._dragging = value


def md5(fname):
    hash_md5 = hashlib.md5()
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


class Geotiff(NetworkObject):
    """
    A class used to add #Geotiffs to the map. The .tiff file is converted to .png during runtime so it
    can be served by the browser, the result of the conversion is saved by default in the "cache" folder.
    This cache can be deleted at any time. Despite the fact that geotiffs define their bounds internally
    you need to specify the #Bounds of your object when instancing it.

    - `file_path`: The path to the .tiff file.
    - `bounds`: The rectangular area the .tiff file should cover.
    """

    cache_path: Optional[str] = None

    def __init__(self, file_path: Path, bounds: Bounds):
        super().__init__()

        if not file_path.is_file():
            raise RuntimeError(f"Invalid Path for Geotiff file ('{file_path}')")

        new_name = f"{md5(file_path)}.png"

        if Geotiff.cache_path is None:
            raise RuntimeError("Create a viewer instance before creating Geotiffs")

        if not Path(os.path.join(Geotiff.cache_path, new_name)).is_file():
            print(f"Converting Geotiff ({file_path}) to PNG")
            options_list = ["-ot Byte", "-of PNG", "-colorinterp red,green,blue,alpha"]
            options_string = " ".join(options_list)

            gdal.Translate(
                os.path.join(Geotiff.cache_path, new_name),
                str(file_path),
                options=options_string,
            )

        self.url = f"local/{new_name}"
        self.bounds = bounds


class Polygon(NetworkObject):
    """
    A class used to draw arbitrary polygons on the map.

    - `points`: The points that define the polygon. You shouldn't add an aditional last point equal
    to the first one as polygons are closed automatically. More information can be found in the
    [Polygon](https://leafletjs.com/reference-1.5.0.html#polygon) docs for Leaflet.
    - `data_panel`: A panel that can be customized. Is accessed by clicking on the Polygon. More information on
    the #Panel documentation.
    - `visual_options`: Graphical options for the polygon.
    Default values for #Polygons and #Vessels:
    ```python
    {
        "stroke": True,         # Outline
        "color": "#3388ff",     # Outline color
        "weight": 3,            # Outline weight
        "opacity": 1.0,         # Outline opacity
        "lineCap": "round",
        "lineJoin": "round",
        "dashArray": None,
        "dashOffset": None,
        "fill": True,           # Fills the polygon
        "fillColor": "#3388ff",
        "fillOpacity": 0.2,
        "fillRule": "evenodd",
    }
    ```
    Other objects like #Lines, #Arrows and #Rudders have the following default values:
    ```python
    {
        "stroke": true,
        "color": "#3388ff",
        "weight": 3,
        "opacity": 1,
        "lineCap": "round",
        "lineJoin": "round",
        "dashArray": null,
        "dashOffset": null,
        "fill": false,
        "fillColor": null,
        "fillOpacity": 0.2,
        "fillRule": "evenodd",
    }
    ```
    See the [Leaflet docs](https://leafletjs.com/reference-1.5.0.html) for more information.

    #### Example:
    ```python
    Polygon(
        points=[
            RelPos(sin(radians(n)) * 400, cos(radians(n)) * 400).to_geo()
            for n in range(0, 360, int(360 / 32))
        ],
        visual_options={"color": "yellow", "fillOpacity": 0.1, "weight": 3},
        data_panel=[
            KeyValue("Poly", "Gone"),
            Button("btn_poly", "Poly"),
            Checkbox("chk_polygon1", "Check Poly", False),
        ],
        draggable=True,
    )
    ```

    ### Methods

    - `is_being_dragged`: Returns `True` if this element is being dragged on the frontend.
    """
    def __init__(
        self,
        points: List[GeoPos],
        data_panel: DataPanel = [],
        visual_options: VisualOptions = {},
        draggable=False,
    ):
        super().__init__()
        self.points = deepcopy(points)
        self.data_panel = deepcopy(data_panel)
        self.visual_options = deepcopy(visual_options)
        self.draggable = draggable
        self._dragging = False  # type: bool

    def is_being_dragged(self):
        return self._dragging

    def set_dragging(self, value: bool):
        """
        Cuidado: Esse método não deve ser chamado pelos clientes da API, ele existe apenas
        para manter a propriedade `_dragging` sincronizada com o navegador.
        """
        self._dragging = value


class Panel(NetworkObject):
    """
    Adds a customizable panel to the screen. This type is just a wrapper for a type called `DataPanel` which
    is defined as a `List[Union[KeyValue, Button, Checkbox, Textbox, ...]]` which means all you need to do is define a
    list of UI elements. #Vessels, #Lines, #Polygons, #Arrows and #Beacons all define a `data_panel` property
    which can be used exactly like this #Panel type except instead of adding a panel to the screen you need to
    click on the object for it to appear.
    Adding more panels than can be seen on the screen will create a scrollbar.
    Large UI elements will stretch the panel horizontally, and since panels are always the same size
    all of your panels will always have the same size as your largest panel.

    To see examples on how to handle UI events see the documentation for #viewer.Venus.

    #### Example:
    ```
    Panel(
        data_panel=[
            KeyValue("Panel", "Value"),
            Button("btn_panel1", "Click here"),
            KeyValue("Value", "Value"),
            Checkbox("chk_drag_elements", "Drag elements", True),
            Checkbox("chk_add_beacons", "Add beacons", False),
        ]
    )
    ```

    - `data_panel`: A panel that can be customized. Shows up on the top right of the screen.
    """
    def __init__(self, data_panel: DataPanel):
        super().__init__()
        self.data_panel = deepcopy(data_panel)
