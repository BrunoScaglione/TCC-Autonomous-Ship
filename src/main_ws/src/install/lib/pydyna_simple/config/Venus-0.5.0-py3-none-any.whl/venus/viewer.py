from venus.server import VenusServer
from venus.network import NetworkObject, serialize, Added, Removed
from venus.objects import GeoPos, Checkbox, Textbox
from typing import TypeVar, List, Optional, Set, Callable, Any
from venus.handlers import WebSocketEventHandler
from tornado.websocket import WebSocketHandler
from logging import getLogger
import json


class ConnectionSuccess:
    def __init__(
        self,
        viewport_center: Optional[GeoPos],
        viewport_zoom: Optional[float],
        mapquest_key: Optional[str],
        objects: List[NetworkObject],
    ):
        self.viewport_center = viewport_center
        self.viewport_zoom = viewport_zoom
        self.mapquest_key = mapquest_key
        self.objects = objects


class ViewportChange:
    def __init__(self, center: GeoPos, zoom: float):
        self.center = center
        self.zoom = zoom


class StartRecording:
    def __init__(self):
        pass


class StopRecording:
    def __init__(self):
        pass


T = TypeVar("T", bound=NetworkObject)


class Venus(WebSocketEventHandler):
    """
    Class used to manage the connection between the python API and the web browser, making sure everything
    is synchronized.

    - `logging`: Whether the server debug messages should be shown, this option is forwarded to the Tornado
    framework. Defaults to `False`
    - `cache_relative_path`: A path relative to your project path where cached files should live. This is used by
    Venus to save the .png version of .tiff files. Defaults to `"cache"`.
    - `port`: The port the server should use. Default address is `localhost:6150`.
    - `auto_start`: Whether a new venus instance automatically starts the web server. Defaults to `True`.

    #### Callbacks

    To interact with UI elements it is necessary to listen to the following callbacks:

    - `on_button_clicked(button_uid)`
    - `on_checkbox_changed(checkbox_uid, checked)`
    - `on_textbox_changed(textbox_uid, value)`
    - `on_object_drag_start(object)`
    - `on_object_drag_end(object, new_geo_position)`
    - `self.on_object_rotate_start(object)`
    - `self.on_object_rotate_end(object, new_angle)`
    - `on_map_clicked(click_geo_position)`

    #### Example

    Add Beacons dynamically if the checkbox `chk_add_beacons` is checked and allow you to drag a vessel if the
    checkbox `chk_drag_elements` is checked.:

    ```python
    panel1 = venus.add(Panel(
        data_panel = [
            Checkbox("chk_drag_elements", "Drag elements", True),
            Checkbox("chk_add_beacons", "Add beacons", False),
        ]
    ))
    vessel1 = venus.add(Vessel(...))
    add_beacons_mode = False

    def on_checkbox_changed(checkbox_uid, checked):
        nonlocal add_beacons_mode

        if checkbox_uid == "chk_drag_elements":
            vessel1.draggable = checked
        elif checkbox_uid == "chk_add_beacons":
            add_beacons_mode = checked

    def on_object_drag_end(obj, new_position):
        if obj == vessel1:
            obj.position = new_position

    def on_map_clicked(pos):
        nonlocal add_beacons_mode

        if add_beacons_mode:
            venus.add(Beacon(
                position=pos,
            ))

    venus.on_checkbox_changed = on_checkbox_changed
    venus.on_object_drag_end = on_object_drag_end
    venus.on_map_clicked = on_map_clicked
    ```

    #### Methods

    - `set_viewport(center: GeoPos, zoom: float)`: Changes the viewport position and zoom.
    - `get_by_uid(uid: int) -> Any`: Find an object by its UID. Used internally by Venus and you should probably
    hold a reference to the objects themselves instead of their UIDs.
    - `add(obj: T) -> T`: Adds an object to Venus. See #venus.objects for your options. The same object is returned
    to you. Adding the same object twice throws a `RuntimeError`.
    - `remove(obj: T)`: Removes an object from Venus. If the object is not found `RuntimeError` is raised.
    - `start()`: Starts the web server. If the server was already started, this method calls `Venus.stop` before
    running.
    - `stop()`: Stops the web server. If the server is not running nothing happens.
    - `clear()`: Deletes every object from Venus.
    - `start_recording()`: Tells the browser it should start recording the user's screen. The browser asks for the user
    permission and recording only starts once permission is given. This feature is experimental, see the `Recording video`
    page for more information.
    - `stop_recording_show_save_prompt()`: Stops the recording and saves the video file.
    """
    def __init__(
        self, mapquest_key: Optional[str] = None, logging: bool = False, cache_relative_path: str = "cache", port=6150, auto_start=True
    ):
        getLogger("tornado.access").disabled = not logging

        self._maquest_key = mapquest_key

        self._network_objects = set()  # type: Set[NetworkObject]
        self._viewport_center = None  # type: Optional[GeoPos]
        self._viewport_zoom = None  # type: Optional[float]

        self.on_button_clicked = None  # type: Optional[Callable[[str], None]]
        self.on_checkbox_changed = None  # type: Optional[Callable[[str, bool], None]]
        self.on_textbox_changed = None  # type: Optional[Callable[[str, str], None]]
        self.on_object_drag_start = None  # type: Optional[Callable[[Any], None]]
        self.on_object_drag_end = None  # type: Optional[Callable[[Any, GeoPos], None]]
        self.on_object_rotate_start = None  # type: Optional[Callable[[Any], None]]
        self.on_object_rotate_end = None  # type: Optional[Callable[[Any, float], None]]
        self.on_map_clicked = None  # type: Optional[Callable[[GeoPos], None]]

        self._server = VenusServer(self, cache_relative_path)
        self._port = port
        if auto_start:
            self.start(port)

    def set_viewport(self, center: GeoPos, zoom: float):
        self._viewport_center = center
        self._viewport_zoom = zoom
        self._server.broadcast(json.dumps(serialize(ViewportChange(center, zoom))))

    def get_by_uid(self, uid: int) -> Any:
        try:
            return next(x for x in self._network_objects if x.uid() == uid)
        except StopIteration:
            raise RuntimeError(f"Object with uid '{uid}' not found")

    def add(self, obj: T) -> T:
        if obj in self._network_objects:
            raise RuntimeError("Object already added")

        obj.set_server(self._server)
        self._network_objects.add(obj)

        # Aqui `obj` é uma instância de Evented mas a checagem de tipos do Python acredita que é
        # um `NetworkObject`. Por isso podemos ignorar o aviso de que não existe `inner` em `T`.
        self._server.broadcast(json.dumps(serialize(Added(obj.inner()))))

        return obj

    def remove(self, obj: T):
        if obj not in self._network_objects:
            raise RuntimeError("Object not found for removal")

        obj.set_server(None)
        self._network_objects.remove(obj)

        self._server.broadcast(json.dumps(serialize(Removed(obj.uid()))))

    def on_ws_open(self, socket: WebSocketHandler):
        msg = json.dumps(
            serialize(
                ConnectionSuccess(
                    self._viewport_center,
                    self._viewport_zoom,
                    self._maquest_key,
                    list(map(lambda o: o.inner(), self._network_objects)),
                )
            )
        )
        socket.write_message(msg)

    def on_ws_message(self, socket: WebSocketHandler, message):
        msg = json.loads(message)
        if msg["__class__"] == "ButtonClicked":
            if self.on_button_clicked is not None:
                self.on_button_clicked(msg["button_uid"])
        elif msg["__class__"] == "CheckboxChanged":
            checkbox_uid = msg["checkbox_uid"]
            checked = msg["checked"]
            obj = self.get_by_uid(msg["parent_uid"])

            checkbox = next(x for x in obj.data_panel if isinstance(x.inner(), Checkbox) and x.uid == checkbox_uid)
            checkbox.inner().checked = checked

            if self.on_checkbox_changed is not None:
                self.on_checkbox_changed(checkbox_uid, checked)

        elif msg["__class__"] == "TextboxChanged":
            textbox_uid = msg["textbox_uid"]
            value = msg["value"]
            obj = self.get_by_uid(msg["parent_uid"])

            textbox = next(x for x in obj.data_panel if isinstance(x.inner(), Textbox) and x.uid == textbox_uid)
            textbox.inner().value = value

            if self.on_textbox_changed is not None:
                self.on_textbox_changed(textbox_uid, value)

        elif msg["__class__"] == "ObjectDragStart":
            obj = self.get_by_uid(msg["object_uid"])
            obj.set_dragging(True)
            if self.on_object_drag_start is not None:
                self.on_object_drag_start(obj)

        elif msg["__class__"] == "ObjectDragEnd":
            obj = self.get_by_uid(msg["object_uid"])
            obj.set_dragging(False)
            if self.on_object_drag_end is not None:
                new_position = GeoPos(msg["new_position"]["latitude"], msg["new_position"]["longitude"])
                self.on_object_drag_end(obj, new_position)

        elif msg["__class__"] == "MapClicked":
            if self.on_map_clicked is not None:
                click_position = GeoPos(msg["latitude"], msg["longitude"])
                self.on_map_clicked(click_position)

        elif msg["__class__"] == "ObjectRotateStart":
            obj = self.get_by_uid(msg["object_uid"])
            obj.set_rotating(True)
            if self.on_object_rotate_start is not None:
                self.on_object_rotate_start(obj)

        elif msg["__class__"] == "ObjectRotateEnd":
            obj = self.get_by_uid(msg["object_uid"])
            obj.set_rotating(False)
            if self.on_object_rotate_end is not None:
                self.on_object_rotate_end(obj, float(msg["new_angle"]))

        else:
            raise RuntimeError(f"Invalid message received: {msg['__class__']}")

    def on_ws_close(self, socket: WebSocketHandler):
        pass

    def start(self, port: Optional[int] = None):
        if not port:
            self._server.start(self._port)
        else:
            self._port = port
            self._server.start(port)

    def stop(self):
        self._server.stop()

    def clear(self):
        all_objects = self._network_objects.copy()
        for obj in all_objects:
            self.remove(obj)

    def start_recording(self):
        msg = json.dumps(
            serialize(StartRecording())
        )
        self._server.broadcast(msg)

    def stop_recording_show_save_prompt(self):
        msg = json.dumps(
            serialize(StopRecording())
        )
        self._server.broadcast(msg)