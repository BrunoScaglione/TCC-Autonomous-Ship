from tornado.websocket import WebSocketHandler
from tornado.web import RequestHandler, Application, StaticFileHandler, HTTPServer
from threading import Thread, Event
from asyncio import set_event_loop, new_event_loop
from tornado.ioloop import IOLoop
from abc import ABC
from typing import Optional, List, Any
import pkg_resources
from venus.handlers import WebSocketEventHandler
from os import path, getcwd
from venus.objects import Geotiff


class VenusWebSocketHandler(WebSocketHandler, ABC):
    def __init__(self, *args, **kwargs):
        WebSocketHandler.__init__(self, *args, **kwargs)
        self._event_handler = kwargs["event_handler"]  # type: WebSocketEventHandler

    def initialize(self, *args, **kwargs):
        # Intencionalmente vazio. Tornado espera que exista um método `initialize`
        # mas não precisamos utilizá-lo.
        pass

    def open(self):
        self._event_handler.on_ws_open(self)

    def on_message(self, message):
        self._event_handler.on_ws_message(self, message)

    def on_close(self):
        self._event_handler.on_ws_close(self)

    def check_origin(self, origin: str) -> bool:
        return True


def lib_static_path(relative_path) -> str:
    resource_package = __name__
    resource_path = relative_path
    return pkg_resources.resource_filename(resource_package, resource_path)


class FileHandler(StaticFileHandler):
    def get_content_type(self):
        if self.absolute_path.endswith(".js"):
            return "application/javascript"

        return StaticFileHandler.get_content_type(self)


class MainHandler(RequestHandler, ABC):
    def get(self):
        resource_path = "/".join(("static", "index.html"))  # Do not use os.path.join()
        self.render(lib_static_path(resource_path))


class VenusServer(Application, WebSocketEventHandler):
    def __init__(self, ws_handler: WebSocketEventHandler, cache_relative_path):
        routes = [
            (r"/", MainHandler),
            (r"/ws", VenusWebSocketHandler, {"event_handler": self}),
            (
                r"/local/(.*)",
                StaticFileHandler,
                {"path": path.join(getcwd(), cache_relative_path)},
            ),
        ]  # type: List[Any]
        WebSocketEventHandler.__init__(self)
        Application.__init__(
            self,
            routes,
            debug=True,
            autoreload=False,
            default_host="0.0.0.0",
            static_handler_class=FileHandler,
            static_path=lib_static_path("static"),
        )
        self._thread = None  # type: Optional[Thread]
        self._http_server = None  # type: Optional[HTTPServer]
        self._io_loop = None  # type: Optional[IOLoop]
        self._connected_sockets = []  # type: List[WebSocketHandler]
        self._ws_handler = ws_handler

        Geotiff.cache_path = cache_relative_path

    def on_ws_open(self, socket: WebSocketHandler):
        self._connected_sockets.append(socket)
        self._ws_handler.on_ws_open(socket)

    def on_ws_message(self, socket: WebSocketHandler, message):
        self._ws_handler.on_ws_message(socket, message)

    def on_ws_close(self, socket: WebSocketHandler):
        self._connected_sockets.remove(socket)
        self._ws_handler.on_ws_close(socket)

    def __do_broadcast(self, message):
        for socket in self._connected_sockets:
            socket.write_message(message)

    def broadcast(self, message):
        # print(message)
        assert self._io_loop is not None
        self._io_loop.add_callback(self.__do_broadcast, message=message)

    @staticmethod
    def _run_server(server, start_event, port):
        set_event_loop(new_event_loop())
        server._io_loop = IOLoop.current(True)
        server._http_server = server.listen(port)
        start_event.set()
        IOLoop.current().start()

    def start(self, port):
        if self._thread is not None:
            self.stop()

        server_start_event = Event()
        self._thread = Thread(
            target=VenusServer._run_server, args=(self, server_start_event, port)
        )
        self._thread.start()
        server_start_event.wait()

    def stop(self):
        self.close_all_connections()
        if self._io_loop is not None:
            assert self._thread is not None
            assert self._http_server is not None
            self._http_server.stop()
            self._io_loop.add_callback(self._io_loop.stop)
            self._thread.join()
            self._io_loop = None
            self._thread = None

    def close_all_connections(self):
        while len(self._connected_sockets) > 0:
            s = self._connected_sockets.pop()
            s.close()
            self._ws_handler.on_ws_close(s)
